import React, { useState, useEffect } from 'react';
import { ThemeMode, Product, FrameColor, CartItem, LensTint, RxType } from './types';
import { PRODUCTS } from './data/products';
import { Header } from './components/Header';
import { BackgroundMotionCanvas } from './components/BackgroundMotionCanvas';
import { HeroSection } from './components/HeroSection';
import { ScrollZoomGallery } from './components/ScrollZoomGallery';
import { InteractiveCustomizer } from './components/InteractiveCustomizer';
import { FrameFinder } from './components/FrameFinder';
import { ReviewsSection } from './components/ReviewsSection';
import { Footer } from './components/Footer';
import { VideoPromptModal } from './components/VideoPromptModal';
import { VirtualTryOnModal } from './components/VirtualTryOnModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistModal } from './components/WishlistModal';
import { Check, ShoppingBag, Heart } from 'lucide-react';

export default function App() {
  // Theme State: 'dark' (Charcoal #121214) or 'light' (Warm Beige #FAF8F5)
  const [theme, setTheme] = useState<ThemeMode>('dark');

  // Video Motion Canvas Mode: 'abstract' or 'studio'
  const [videoMode, setVideoMode] = useState<'abstract' | 'studio'>('abstract');

  // Catalog State
  const [products] = useState<Product[]>(PRODUCTS);
  const [selectedProduct, setSelectedProduct] = useState<Product>(PRODUCTS[0]);
  const [modalProduct, setModalProduct] = useState<Product | null>(null);
  const [modalInitialColorId, setModalInitialColorId] = useState<string | undefined>(undefined);

  // Shopping Cart & Wishlist State
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('mgw_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('mgw_wishlist');
      return saved ? JSON.parse(saved) : ['mgw-a1-aeronaut'];
    } catch {
      return ['mgw-a1-aeronaut'];
    }
  });

  // Modals & Drawers
  const [isPromptModalOpen, setIsPromptModalOpen] = useState(false);
  const [isTryOnModalOpen, setIsTryOnModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('mgw_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error(e);
    }
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem('mgw_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {
      console.error(e);
    }
  }, [wishlistIds]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleAddToCart = (product: Product, color: FrameColor) => {
    const existingIndex = cartItems.findIndex(
      (item) =>
        item.product.id === product.id &&
        item.color.id === color.id &&
        item.lensTint === 'Clear Anti-Reflective'
    );

    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += 1;
      setCartItems(updated);
    } else {
      const newItem: CartItem = {
        id: `cart-${Date.now()}`,
        product,
        color,
        lensTint: 'Clear Anti-Reflective',
        rxType: 'Non-Prescription (Plano)',
        price: product.price,
        quantity: 1
      };
      setCartItems([newItem, ...cartItems]);
    }

    showToast(`Added "${product.name} (${color.name})" to shopping bag`);
    setIsCartOpen(true);
  };

  const handleAddCustomizedToCart = (customized: {
    product: Product;
    color: FrameColor;
    lensTint: LensTint;
    rxType: RxType;
    engravingText: string;
    hingeFinish: string;
    totalPrice: number;
  }) => {
    const newItem: CartItem = {
      id: `cart-custom-${Date.now()}`,
      product: customized.product,
      color: customized.color,
      lensTint: customized.lensTint,
      rxType: customized.rxType,
      engravingText: customized.engravingText,
      hingeFinish: customized.hingeFinish,
      price: customized.totalPrice,
      quantity: 1
    };

    setCartItems([newItem, ...cartItems]);
    showToast(`Added Bespoke "${customized.product.name}" to shopping bag`);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleToggleWishlist = (productId: string) => {
    if (wishlistIds.includes(productId)) {
      setWishlistIds((prev) => prev.filter((id) => id !== productId));
      showToast('Removed from saved wishlist');
    } else {
      setWishlistIds((prev) => [...prev, productId]);
      showToast('Saved to wishlist');
    }
  };

  const handleOpenDetailModal = (product: Product, initialColorId?: string) => {
    setModalProduct(product);
    setModalInitialColorId(initialColorId);
    setIsDetailModalOpen(true);
  };

  const handleOpenCustomizerForProduct = (product: Product, colorId?: string) => {
    setSelectedProduct(product);
    const el = document.getElementById('customizer-section');
    if (el) {
      const yOffset = -70;
      const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  const handleOpenTryOnForProduct = (product: Product) => {
    setSelectedProduct(product);
    setIsTryOnModalOpen(true);
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const yOffset = -70;
      const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  const isDark = theme === 'dark';

  return (
    <div
      id="mgw-root-container"
      className={`min-h-screen relative font-sans transition-colors duration-500 selection:bg-violet-500 selection:text-white ${
        isDark ? 'bg-[#07070b] text-neutral-100' : 'bg-[#f4f3f7] text-neutral-900'
      }`}
    >
      {/* Frosted Glass Ambient Atmospheric Radial Glows */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div
          className={`absolute top-[-10%] left-[-10%] w-[60vw] h-[60vw] rounded-full blur-[140px] transition-opacity duration-700 ${
            isDark
              ? 'bg-gradient-to-br from-violet-900/25 via-indigo-950/20 to-transparent opacity-80'
              : 'bg-gradient-to-br from-violet-200/40 via-purple-100/30 to-transparent opacity-70'
          }`}
        />
        <div
          className={`absolute top-[40%] right-[-15%] w-[55vw] h-[55vw] rounded-full blur-[160px] transition-opacity duration-700 ${
            isDark
              ? 'bg-gradient-to-tl from-purple-900/20 via-violet-950/15 to-transparent opacity-70'
              : 'bg-gradient-to-tl from-amber-100/40 via-purple-100/30 to-transparent opacity-60'
          }`}
        />
        <div
          className={`absolute bottom-[-10%] left-[20%] w-[50vw] h-[50vw] rounded-full blur-[150px] transition-opacity duration-700 ${
            isDark
              ? 'bg-gradient-to-tr from-violet-950/20 via-blue-950/15 to-transparent opacity-60'
              : 'bg-gradient-to-tr from-violet-100/30 via-indigo-50/30 to-transparent opacity-60'
          }`}
        />
      </div>

      {/* Background Animated Video Motion Canvas */}
      <BackgroundMotionCanvas
        mode={videoMode}
        theme={theme}
        onToggleMode={(m) => setVideoMode(m)}
        onOpenPromptModal={() => setIsPromptModalOpen(true)}
      />

      {/* Main Top Navigation Header with 1-click Theme Toggle */}
      <Header
        theme={theme}
        onToggleTheme={handleToggleTheme}
        cartCount={cartItems.reduce((acc, i) => acc + i.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        wishlistCount={wishlistIds.length}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenVirtualTryOn={() => setIsTryOnModalOpen(true)}
      />

      {/* Main 5-Section Layout */}
      <main className="relative z-10">
        {/* Section 1: Hero Header Section (Main Entry) */}
        <HeroSection
          theme={theme}
          onExploreCollection={() => scrollToSection('gallery-section')}
          onOpenFaceFinder={() => scrollToSection('frame-finder-section')}
          onOpenCustomizer={() => scrollToSection('customizer-section')}
          onOpenPromptModal={() => setIsPromptModalOpen(true)}
          onOpenTryOn={() => setIsTryOnModalOpen(true)}
        />

        {/* Section 2: Interactive Product Gallery (Zoom-On-Scroll) */}
        <ScrollZoomGallery
          products={products}
          theme={theme}
          onSelectProduct={handleOpenDetailModal}
          onOpenCustomizerForProduct={handleOpenCustomizerForProduct}
          onOpenTryOnForProduct={handleOpenTryOnForProduct}
          onAddToCart={handleAddToCart}
          wishlistIds={wishlistIds}
          onToggleWishlist={handleToggleWishlist}
        />

        {/* Section 3: Interactive Customizer & 300% Detail Inspector */}
        <InteractiveCustomizer
          products={products}
          selectedProduct={selectedProduct}
          onSelectProduct={(p) => setSelectedProduct(p)}
          theme={theme}
          onAddToCart={handleAddCustomizedToCart}
          onOpenTryOn={handleOpenTryOnForProduct}
        />

        {/* Section 4: Frame Finder & Style Guide (3-Step Face Shape Tool) */}
        <FrameFinder
          products={products}
          theme={theme}
          onSelectProduct={handleOpenDetailModal}
          onOpenCustomizer={handleOpenCustomizerForProduct}
          onOpenTryOn={handleOpenTryOnForProduct}
        />

        {/* Section 5: Customer Reviews & Verified Fit Feedback */}
        <ReviewsSection theme={theme} />
      </main>

      {/* Luxury Footer with Warranty & AI Video Prompts */}
      <Footer
        theme={theme}
        onOpenPromptModal={() => setIsPromptModalOpen(true)}
        onOpenFaceFinder={() => scrollToSection('frame-finder-section')}
        onOpenVirtualTryOn={() => setIsTryOnModalOpen(true)}
      />

      {/* Modals & Overlays */}
      <VideoPromptModal
        isOpen={isPromptModalOpen}
        onClose={() => setIsPromptModalOpen(false)}
        theme={theme}
      />

      <VirtualTryOnModal
        isOpen={isTryOnModalOpen}
        onClose={() => setIsTryOnModalOpen(false)}
        products={products}
        activeProduct={selectedProduct}
        onSelectProduct={(p) => setSelectedProduct(p)}
        theme={theme}
        onAddToCart={handleAddToCart}
        onOpenCustomizer={handleOpenCustomizerForProduct}
      />

      <ProductDetailModal
        product={modalProduct}
        initialColorId={modalInitialColorId}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        theme={theme}
        onAddToCart={handleAddToCart}
        onOpenCustomizer={handleOpenCustomizerForProduct}
        onOpenTryOn={handleOpenTryOnForProduct}
        isWishlisted={modalProduct ? wishlistIds.includes(modalProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        theme={theme}
      />

      <WishlistModal
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistIds={wishlistIds}
        products={products}
        onRemoveFromWishlist={handleToggleWishlist}
        onAddToCart={handleAddToCart}
        onOpenCustomizer={handleOpenCustomizerForProduct}
        theme={theme}
      />

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div
          id="toast-notification"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-5 py-3 rounded-full bg-black/60 text-white text-xs font-semibold shadow-2xl border border-white/15 backdrop-blur-xl animate-fadeIn"
        >
          <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
            <Check className="w-3 h-3" />
          </div>
          <span className="tracking-wide">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
