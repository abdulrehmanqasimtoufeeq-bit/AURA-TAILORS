import { Review } from '../types';

export const REVIEWS_DATA: Review[] = [
  {
    id: 'rev-1',
    author: 'Marcus Sterling',
    location: 'London, UK',
    rating: 5,
    title: 'Flawless balance and featherweight titanium engineering.',
    content: 'I wear the Aeronaut Titanium daily for 12+ hour trading sessions. You genuinely forget you have them on. The micro-grooved nose pads leave zero red marks, and the anti-reflective coating handles multi-monitor glare effortlessly.',
    date: '2 days ago',
    verified: true,
    frameModel: 'Aeronaut Titanium 01',
    frameColor: 'Matte Stealth Black',
    fitRating: 'True to Size',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'rev-2',
    author: 'Julian Vance',
    location: 'Zurich, Switzerland',
    rating: 5,
    title: 'The Italian acetate beveling is a work of industrial art.',
    content: 'The Monolith Wayfarer has incredible presence. The 7-barrel hinges feel tight and solid with satisfying mechanical resistance. Switched to the Sapphire Blue-Block lenses and my evening eye fatigue vanished completely.',
    date: '1 week ago',
    verified: true,
    frameModel: 'Monolith Wayfarer 02',
    frameColor: 'Havana Tortoiseshell',
    fitRating: 'True to Size',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'rev-3',
    author: 'Dr. Arthur Pendelton',
    location: 'Boston, MA',
    rating: 5,
    title: 'Virtual fit guide was 100% spot-on for my square jawline.',
    content: 'I used the 3-step Face Finder tool and selected the Panthos Circle in Brushed Gunmetal. The circular silhouette softens my angular jaw perfectly. The craftsmanship on the coin-edge filigree rival bespoke Savile Row tailoring.',
    date: '2 weeks ago',
    verified: true,
    frameModel: 'Panthos Circle 03',
    frameColor: 'Brushed Gunmetal',
    fitRating: 'True to Size',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'rev-4',
    author: 'Soren Lindqvist',
    location: 'Stockholm, Sweden',
    rating: 5,
    title: 'Under 10 grams! The Strata Rimless redefined eyewear for me.',
    content: 'Zero screw wobbles or loose parts thanks to the compression plug design. I personalized mine with the 24k Gold Ion hinges and custom initials laser-engraved. MGW customer service was exceptional.',
    date: '3 weeks ago',
    verified: true,
    frameModel: 'Strata Minimal Rimless 05',
    frameColor: 'Pure Titanium Gold',
    fitRating: 'Generous Fit',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'rev-5',
    author: 'Elena & Harrison Ross',
    location: 'Chicago, IL',
    rating: 5,
    title: 'Bought for my husband’s promotion — he has not taken them off.',
    content: 'The packaging presentation, aluminum protective vault, and micro-fiber polishing cloth feel like unboxing a Patek Philippe watch. The Vanguard Square frames give him a sharp, commanding executive presence.',
    date: '1 month ago',
    verified: true,
    frameModel: 'Vanguard Square 04',
    frameColor: 'Smoked Slate Ash',
    fitRating: 'True to Size',
    avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=200&q=80'
  }
];

export const BRAND_STATS = [
  { label: 'Grade-5 Aerospace Titanium', value: '100%' },
  { label: 'Featherweight Average Frame', value: '13.8g' },
  { label: 'Hinge Cycle Rating', value: '50k+' },
  { label: 'Global Satisfied Gentlemen', value: '24,000+' }
];
