import { Product } from '../types';

export const PRODUCTS: Product[] = [
  {
    id: 'mgw-a1-aeronaut',
    name: 'Aeronaut Titanium 01',
    series: 'Apex Flight Series',
    tagline: 'Dual-bridge Japanese aerospace titanium aviator with precision milled brow bar.',
    price: 345,
    originalPrice: 395,
    rating: 4.9,
    reviewsCount: 128,
    category: 'Aviator',
    bestForFaceShapes: ['Square', 'Heart', 'Oval'],
    material: 'Beta-Titanium',
    colors: [
      { id: 'matte-black', name: 'Matte Stealth Black', hex: '#1C1C1E', borderHex: '#3A3A3C' },
      { id: 'gunmetal-grey', name: 'Gunmetal Grey', hex: '#4A4C50', borderHex: '#63666A' },
      { id: 'brushed-gold', name: 'Brushed 18k Champagne', hex: '#C5A880', borderHex: '#D8C3A5' },
      { id: 'soft-beige', name: 'Desert Sand Dune', hex: '#D7C7B2', borderHex: '#EAE0D5' }
    ],
    dimensions: {
      lensWidth: 54,
      bridgeWidth: 17,
      templeLength: 145,
      frameWeight: 13.8
    },
    description: 'Re-engineering the classic aviator for the modern gentleman. Cut from surgical-grade Japanese Beta-Titanium, the Aeronaut weighs under 14 grams while offering structural rigidity, seamless barrel hinges, and micro-grooved nose pads.',
    craftDetails: [
      'Ultralight 13.8g Grade-5 Beta-Titanium structure',
      'Dual-bridge with hand-milled tension damper',
      'Proprietary 5-barrel hinge with micro-screw locking',
      '100% Anti-reflective, Oleophobic & UV400 multi-layer lenses'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?auto=format&fit=crop&w=1200&q=85',
    angleImageUrl: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=1200&q=85',
    hingeImageUrl: 'https://images.unsplash.com/photo-1577803645773-f96470509666?auto=format&fit=crop&w=1200&q=85',
    modelImageUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=1000&q=85',
    lensTints: ['Clear Anti-Reflective', 'Emerald Polarized', 'Sapphire Blue-Block', 'Amber Sunset', 'Gradient Charcoal'],
    isBestSeller: true,
    isNew: false,
    inStock: true
  },
  {
    id: 'mgw-w2-monolith',
    name: 'Monolith Wayfarer 02',
    series: 'Architectural Acetate',
    tagline: 'Bold beveled 8mm Mazzucchelli Italian acetate with wire-core sculpted temples.',
    price: 320,
    rating: 4.8,
    reviewsCount: 94,
    category: 'Wayfarer',
    bestForFaceShapes: ['Round', 'Oval', 'Heart'],
    material: 'Mazzucchelli Acetate',
    colors: [
      { id: 'matte-black', name: 'Onyx Matte Black', hex: '#151515', borderHex: '#333333' },
      { id: 'tortoiseshell', name: 'Havana Tortoiseshell', hex: '#634832', borderHex: '#8C6239' },
      { id: 'soft-beige', name: 'Champagne Crystal Beige', hex: '#E6DCB8', borderHex: '#C5B990' },
      { id: 'gunmetal-grey', name: 'Smoked Slate Ash', hex: '#3B3F46', borderHex: '#525760' }
    ],
    dimensions: {
      lensWidth: 51,
      bridgeWidth: 20,
      templeLength: 145,
      frameWeight: 26.2
    },
    description: 'An imposing modern statement crafted from cured block acetate. Diamond-cut beveling catches ambient light while the custom inner wire core ensures tailored ergonomic comfort behind the ears.',
    craftDetails: [
      'Organic plant-based Mazzucchelli 1849 Italian acetate',
      '7-barrel custom reinforced pin hinges with laser serial',
      'Sculpted temple tips with internal weight counter-balance',
      'Dual-side diamond-hard anti-scratch coating'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1508296695146-257a814070b4?auto=format&fit=crop&w=1200&q=85',
    angleImageUrl: 'https://images.unsplash.com/photo-1591076482161-42ce6da69f67?auto=format&fit=crop&w=1200&q=85',
    hingeImageUrl: 'https://images.unsplash.com/photo-1509695503492-4122d64f0b2f?auto=format&fit=crop&w=1200&q=85',
    modelImageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1000&q=85',
    lensTints: ['Clear Anti-Reflective', 'Sapphire Blue-Block', 'Gradient Charcoal', 'Emerald Polarized'],
    isBestSeller: true,
    isNew: true,
    inStock: true
  },
  {
    id: 'mgw-r3-panthos',
    name: 'Panthos Circle 03',
    series: 'Heritage Intellectual',
    tagline: 'Sculpted round panto silhouette with keyhole bridge and featherweight titanium rim.',
    price: 360,
    originalPrice: 410,
    rating: 5.0,
    reviewsCount: 76,
    category: 'Round',
    bestForFaceShapes: ['Square', 'Diamond', 'Heart'],
    material: 'Beta-Titanium',
    colors: [
      { id: 'gunmetal-grey', name: 'Brushed Gunmetal', hex: '#484B50', borderHex: '#666A72' },
      { id: 'tortoiseshell', name: 'Vintage Dark Tortoise', hex: '#583D28', borderHex: '#7A5438' },
      { id: 'matte-black', name: 'Midnight Charcoal', hex: '#222328', borderHex: '#40434C' },
      { id: 'soft-beige', name: 'Soft Ecru Sand', hex: '#DED6C9', borderHex: '#C5BBAA' }
    ],
    dimensions: {
      lensWidth: 48,
      bridgeWidth: 21,
      templeLength: 142,
      frameWeight: 14.2
    },
    description: 'Inspired by 1950s architectural masters and modernized through Japanese micro-lathe fabrication. The Panthos frame features an authentic keyhole bridge balanced by slim titanium wire temples.',
    craftDetails: [
      'Micro-engraved filigree on coin-edge rim perimeter',
      'Ultra-ergonomic keyhole bridge distributing zero nasal pressure',
      'Pure Grade-5 Japanese Titanium with PVD scratch-proof ion plating',
      'High index 1.67 ultra-thin blue light precision optics'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1473496169904-658ba7c44d8a?auto=format&fit=crop&w=1200&q=85',
    angleImageUrl: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=1200&q=85',
    hingeImageUrl: 'https://images.unsplash.com/photo-1577803645773-f96470509666?auto=format&fit=crop&w=1200&q=85',
    modelImageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=1000&q=85',
    lensTints: ['Clear Anti-Reflective', 'Sapphire Blue-Block', 'Amber Sunset', 'Emerald Polarized'],
    isBestSeller: false,
    isNew: true,
    inStock: true
  },
  {
    id: 'mgw-s4-vanguard',
    name: 'Vanguard Square 04',
    series: 'Executive Precision',
    tagline: 'Crisp geometric rectangular frame with chamfered bridge and stealth gunmetal accents.',
    price: 310,
    rating: 4.8,
    reviewsCount: 112,
    category: 'Square',
    bestForFaceShapes: ['Round', 'Oval'],
    material: 'Monel Alloy',
    colors: [
      { id: 'gunmetal-grey', name: 'Gunmetal Grey', hex: '#3E4249', borderHex: '#585D67' },
      { id: 'matte-black', name: 'Matte Black Ceramic', hex: '#1E1F22', borderHex: '#3B3E45' },
      { id: 'soft-beige', name: 'Soft Cashmere Beige', hex: '#E2D9CC', borderHex: '#C9BEAD' },
      { id: 'tortoiseshell', name: 'Amber Smoked Tortoise', hex: '#6A4325', borderHex: '#8D5B33' }
    ],
    dimensions: {
      lensWidth: 53,
      bridgeWidth: 18,
      templeLength: 145,
      frameWeight: 18.5
    },
    description: 'Designed for boardroom clarity and sharp profile lines. Precision milled chamfers flank the upper rim, lending a confident, grounded silhouette to round and oval face shapes.',
    craftDetails: [
      'Corrosion-resistant forged Monel and titanium hybrid build',
      'Dual-axis spring flex hinges rated for 50,000+ open-close cycles',
      'Hypoallergenic medical grade silicone nose pads with air-pocket cushioning',
      'Anti-fog, oleophobic hydrophobic multi-shield lens coatings'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1582142306909-195724d33ffc?auto=format&fit=crop&w=1200&q=85',
    angleImageUrl: 'https://images.unsplash.com/photo-1508296695146-257a814070b4?auto=format&fit=crop&w=1200&q=85',
    hingeImageUrl: 'https://images.unsplash.com/photo-1577803645773-f96470509666?auto=format&fit=crop&w=1200&q=85',
    modelImageUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=1000&q=85',
    lensTints: ['Clear Anti-Reflective', 'Sapphire Blue-Block', 'Gradient Charcoal'],
    isBestSeller: false,
    isNew: false,
    inStock: true
  },
  {
    id: 'mgw-x5-strata',
    name: 'Strata Minimal Rimless 05',
    series: 'Zero-Mass Studio',
    tagline: 'Ultralight 9.4g screwless rimless architecture with tension-mounted temples.',
    price: 390,
    originalPrice: 440,
    rating: 4.9,
    reviewsCount: 88,
    category: 'Rimless',
    bestForFaceShapes: ['Oval', 'Round', 'Square', 'Heart', 'Diamond'],
    material: 'Rimless Carbon-Titanium',
    colors: [
      { id: 'gunmetal-grey', name: 'Polished Gunmetal', hex: '#52565E', borderHex: '#717682' },
      { id: 'matte-black', name: 'Stealth Shadow Black', hex: '#1A1A1A', borderHex: '#333333' },
      { id: 'soft-beige', name: 'Champagne Warm Beige', hex: '#DDD2BF', borderHex: '#C5B69F' },
      { id: 'brushed-gold', name: 'Pure Titanium Gold', hex: '#C2A374', borderHex: '#D9BE94' }
    ],
    dimensions: {
      lensWidth: 52,
      bridgeWidth: 19,
      templeLength: 140,
      frameWeight: 9.4
    },
    description: 'The pinnacle of minimalist eyewear engineering. Zero visible screws, zero rim obstruction, and an almost weightless footprint of 9.4 grams. Form fitted to deliver an uninterrupted field of view.',
    craftDetails: [
      'Featherweight 9.4g pure Japanese carbon-titanium alloy',
      'Patented compression plug lens mount with zero screw vibration',
      'Custom lens shape tailoring (Octagonal, Rounded, Classic Square)',
      'Diamond polished edge beveling with 99.8% light transmission'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1591076482161-42ce6da69f67?auto=format&fit=crop&w=1200&q=85',
    angleImageUrl: 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?auto=format&fit=crop&w=1200&q=85',
    hingeImageUrl: 'https://images.unsplash.com/photo-1509695503492-4122d64f0b2f?auto=format&fit=crop&w=1200&q=85',
    modelImageUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=1000&q=85',
    lensTints: ['Clear Anti-Reflective', 'Sapphire Blue-Block', 'Emerald Polarized', 'Gradient Charcoal'],
    isBestSeller: true,
    isNew: true,
    inStock: true
  },
  {
    id: 'mgw-k6-chancellor',
    name: 'Chancellor Square Aviator 06',
    series: 'Executive Hybrid',
    tagline: 'Square navigator with brushed titanium brow accent and tortoiseshell temple tips.',
    price: 335,
    rating: 4.7,
    reviewsCount: 65,
    category: 'Aviator',
    bestForFaceShapes: ['Round', 'Oval', 'Heart'],
    material: 'Beta-Titanium',
    colors: [
      { id: 'tortoiseshell', name: 'Royal Havana & Gunmetal', hex: '#533B27', borderHex: '#7B5738' },
      { id: 'matte-black', name: 'Matte Charcoal & Gold', hex: '#202022', borderHex: '#404044' },
      { id: 'soft-beige', name: 'Warm Beige Cream', hex: '#E4DCcf', borderHex: '#CFC3B0' },
      { id: 'gunmetal-grey', name: 'Smoked Pewter', hex: '#454950', borderHex: '#60656E' }
    ],
    dimensions: {
      lensWidth: 55,
      bridgeWidth: 17,
      templeLength: 145,
      frameWeight: 16.1
    },
    description: 'A bold, assertive fusion of navigator square geometry with the classic double bridge. Hand-finished acetate temple sleeves guarantee balanced comfort during all-day wear.',
    craftDetails: [
      'Dual material fusion: Grade-5 Titanium chassis + Mazzucchelli tips',
      'Laser-sculpted horizontal brow vent for aerodynamic luxury appeal',
      'Direct-molded silicone nose pads with non-slip micro-ribs',
      'Hydrophobic anti-glare Zeiss certified optical grade lenses'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1577803645773-f96470509666?auto=format&fit=crop&w=1200&q=85',
    angleImageUrl: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=1200&q=85',
    hingeImageUrl: 'https://images.unsplash.com/photo-1509695503492-4122d64f0b2f?auto=format&fit=crop&w=1200&q=85',
    modelImageUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=1000&q=85',
    lensTints: ['Clear Anti-Reflective', 'Amber Sunset', 'Emerald Polarized', 'Sapphire Blue-Block'],
    isBestSeller: false,
    isNew: false,
    inStock: true
  }
];

export const LENS_TINTS_DATA = [
  {
    name: 'Clear Anti-Reflective',
    subtitle: 'Zero Glare & High Index Clarity',
    colorHex: 'rgba(230, 245, 255, 0.4)',
    badge: 'Daily Essential',
    priceDelta: 0
  },
  {
    name: 'Sapphire Blue-Block',
    subtitle: 'Digital Blue Light Filter (420nm)',
    colorHex: 'rgba(96, 165, 250, 0.45)',
    badge: 'Screen Work',
    priceDelta: 35
  },
  {
    name: 'Emerald Polarized',
    subtitle: 'Hydrophobic Anti-Glare Polarized',
    colorHex: 'rgba(52, 211, 153, 0.45)',
    badge: 'Outdoor Driving',
    priceDelta: 60
  },
  {
    name: 'Amber Sunset',
    subtitle: 'High-Contrast Depth Perception',
    colorHex: 'rgba(251, 146, 60, 0.45)',
    badge: 'Golden Hour',
    priceDelta: 45
  },
  {
    name: 'Gradient Charcoal',
    subtitle: 'Executive Tint (75% to 20%)',
    colorHex: 'rgba(30, 41, 59, 0.65)',
    badge: 'Luxury Sun',
    priceDelta: 50
  }
];
