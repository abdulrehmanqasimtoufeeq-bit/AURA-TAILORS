export type ThemeMode = 'dark' | 'light';

export type FrameCategory = 'All' | 'Aviator' | 'Wayfarer' | 'Round' | 'Square' | 'Rimless';

export type FaceShape = 'Round' | 'Oval' | 'Square' | 'Heart' | 'Diamond';

export type MaterialType = 'Beta-Titanium' | 'Mazzucchelli Acetate' | 'Monel Alloy' | 'Rimless Carbon-Titanium';

export type LensTint = 'Clear Anti-Reflective' | 'Emerald Polarized' | 'Sapphire Blue-Block' | 'Amber Sunset' | 'Gradient Charcoal';

export type RxType = 'Non-Prescription (Plano)' | 'Single Vision (Distance/Reading)' | 'Progressive Multifocal' | 'Digital Blue Light Filter';

export interface FrameColor {
  id: string;
  name: string;
  hex: string;
  borderHex?: string;
}

export interface FrameDimensions {
  lensWidth: number;   // e.g. 52 mm
  bridgeWidth: number; // e.g. 19 mm
  templeLength: number;// e.g. 145 mm
  frameWeight: number; // e.g. 14 grams
}

export interface Product {
  id: string;
  name: string;
  series: string;
  tagline: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  category: 'Aviator' | 'Wayfarer' | 'Round' | 'Square' | 'Rimless';
  bestForFaceShapes: FaceShape[];
  material: MaterialType;
  colors: FrameColor[];
  dimensions: FrameDimensions;
  description: string;
  craftDetails: string[];
  imageUrl: string;
  angleImageUrl: string;
  hingeImageUrl: string;
  modelImageUrl: string;
  lensTints: LensTint[];
  isBestSeller?: boolean;
  isNew?: boolean;
  inStock: boolean;
}

export interface CustomizerSelection {
  productId: string;
  colorId: string;
  lensTint: LensTint;
  rxType: RxType;
  engravingText: string;
  hingeFinish: 'Brushed Platinum' | 'Matte Black Titanium' | '24k Gold Ion';
}

export interface CartItem {
  id: string;
  product: Product;
  color: FrameColor;
  lensTint: LensTint;
  rxType: RxType;
  engravingText?: string;
  hingeFinish?: string;
  price: number;
  quantity: number;
}

export interface Review {
  id: string;
  author: string;
  location: string;
  rating: number;
  title: string;
  content: string;
  date: string;
  verified: boolean;
  frameModel: string;
  frameColor: string;
  fitRating: 'Runs Narrow' | 'True to Size' | 'Generous Fit';
  avatarUrl?: string;
}

export interface FaceQuizState {
  faceShape: FaceShape | null;
  styleVibe: 'Executive Minimalist' | 'Bold Statement' | 'Classic Architectural' | 'Ultralight Performance' | null;
  preferredFinish: string | null;
}
