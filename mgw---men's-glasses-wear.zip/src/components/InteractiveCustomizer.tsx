import React, { useState, useRef } from 'react';
import {
  Product,
  ThemeMode,
  LensTint,
  RxType,
  FrameColor
} from '../types';
import { LENS_TINTS_DATA } from '../data/products';
import {
  ZoomIn,
  Sliders,
  Sparkles,
  Check,
  ShoppingBag,
  ShieldCheck,
  RotateCcw,
  Eye,
  Type,
  Maximize2
} from 'lucide-react';

interface InteractiveCustomizerProps {
  products: Product[];
  selectedProduct: Product;
  onSelectProduct: (product: Product) => void;
  theme: ThemeMode;
  onAddToCart: (customizedItem: {
    product: Product;
    color: FrameColor;
    lensTint: LensTint;
    rxType: RxType;
    engravingText: string;
    hingeFinish: string;
    totalPrice: number;
  }) => void;
  onOpenTryOn: (product: Product) => void;
}

export const InteractiveCustomizer: React.FC<InteractiveCustomizerProps> = ({
  products,
  selectedProduct,
  onSelectProduct,
  theme,
  onAddToCart,
  onOpenTryOn
}) => {
  const isDark = theme === 'dark';

  // Customizer State
  const [selectedColorId, setSelectedColorId] = useState<string>(
    selectedProduct.colors[0]?.id || 'matte-black'
  );
  const [selectedLensTint, setSelectedLensTint] = useState<LensTint>('Clear Anti-Reflective');
  const [selectedRx, setSelectedRx] = useState<RxType>('Non-Prescription (Plano)');
  const [engravingText, setEngravingText] = useState<string>('MGW-2026');
  const [hingeFinish, setHingeFinish] = useState<'Brushed Platinum' | 'Matte Black Titanium' | '24k Gold Ion'>('Brushed Platinum');
  const [inspectorActiveSpot, setInspectorActiveSpot] = useState<'hinge' | 'bridge' | 'temple' | 'nosepad'>('hinge');
  const [isZoomMode, setIsZoomMode] = useState<boolean>(false);
  const [mouseZoomPos, setMouseZoomPos] = useState({ x: 50, y: 50 });
  const imageContainerRef = useRef<HTMLDivElement | null>(null);

  // Sync selectedColorId if product changes
  React.useEffect(() => {
    if (!selectedProduct.colors.some((c) => c.id === selectedColorId)) {
      setSelectedColorId(selectedProduct.colors[0].id);
    }
  }, [selectedProduct]);

  const currentColor =
    selectedProduct.colors.find((c) => c.id === selectedColorId) || selectedProduct.colors[0];

  const currentTintData =
    LENS_TINTS_DATA.find((t) => t.name === selectedLensTint) || LENS_TINTS_DATA[0];

  const rxPriceMap: Record<RxType, number> = {
    'Non-Prescription (Plano)': 0,
    'Digital Blue Light Filter': 40,
    'Single Vision (Distance/Reading)': 85,
    'Progressive Multifocal': 160
  };

  const hingePriceMap = {
    'Brushed Platinum': 0,
    'Matte Black Titanium': 15,
    '24k Gold Ion': 35
  };

  const engravingPrice = engravingText.trim().length > 0 ? 25 : 0;

  const calculatedTotal =
    selectedProduct.price +
    currentTintData.priceDelta +
    rxPriceMap[selectedRx] +
    hingePriceMap[hingeFinish] +
    engravingPrice;

  // Handle 300% Zoom Loupe hover tracking
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imageContainerRef.current) return;
    const rect = imageContainerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setMouseZoomPos({ x, y });
  };

  const INSPECTOR_SPOTS = [
    {
      id: 'hinge',
      label: '5-Barrel Hinge',
      desc: 'Precision micro-screw locking rated for 50k cycles',
      x: 18,
      y: 35
    },
    {
      id: 'bridge',
      label: 'Titanium Bridge',
      desc: 'Laser-welded stress damper with zero flex fatigue',
      x: 50,
      y: 40
    },
    {
      id: 'temple',
      label: 'Engraved Arm',
      desc: 'Laser-inscribed personalization & inner wire core',
      x: 82,
      y: 46
    },
    {
      id: 'nosepad',
      label: 'Silicone Nose Pads',
      desc: 'Featherweight air-cushioned hypoallergenic pads',
      x: 46,
      y: 58
    }
  ];

  return (
    <section
      id="customizer-section"
      className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10"
    >
      {/* Section Tag */}
      <div className="flex items-center gap-2.5 mb-2">
        <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
        <span
          className={`text-xs font-mono font-bold uppercase tracking-widest ${
            isDark ? 'text-amber-400' : 'text-amber-800'
          }`}
        >
          Section 03 — Interactive Customizer
        </span>
      </div>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-white/10 dark:border-white/10">
        <div>
          <h2
            id="customizer-title"
            className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight font-sans"
          >
            Customizer &{' '}
            <span className="font-serif italic font-normal text-amber-400">
              300% Detail Inspector
            </span>
          </h2>
          <p
            className={`mt-2 text-sm sm:text-base max-w-2xl ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}
          >
            Hover anywhere on the frame canvas below to activate the 300% optical magnification loupe.
            Tailor lens coatings, frame alloy finishes, and bespoke laser temple engravings.
          </p>
        </div>

        {/* Model Selector Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 p-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-xl">
          <span className="text-xs font-mono text-neutral-400 uppercase hidden sm:inline pl-2">Model:</span>
          {products.map((p) => (
            <button
              key={p.id}
              onClick={() => onSelectProduct(p)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                selectedProduct.id === p.id
                  ? isDark
                    ? 'bg-white text-black font-bold shadow-md'
                    : 'bg-neutral-900 text-white font-bold shadow-md'
                  : isDark
                  ? 'text-neutral-300 hover:text-white hover:bg-white/10'
                  : 'text-neutral-700 hover:text-neutral-900 hover:bg-black/5'
              }`}
            >
              {p.name.split(' ')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Main 2-Column Customizer & Inspector Studio */}
      <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Interactive 300% Zoom Canvas & Hotspot Inspector (7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div
            className={`relative rounded-2xl border overflow-hidden p-6 sm:p-8 flex flex-col justify-between min-h-[480px] sm:min-h-[540px] transition-all backdrop-blur-xl ${
              isDark
                ? 'bg-white/[0.03] border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
                : 'bg-white/70 border-white/60 shadow-xl'
            }`}
          >
            {/* Top Canvas Bar */}
            <div className="flex items-center justify-between z-20">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-white/10 text-white border border-white/15 backdrop-blur-xl shadow-sm">
                  {selectedProduct.category} • {selectedProduct.material}
                </span>
                <span className="text-xs font-mono text-neutral-400 hidden sm:inline">
                  {selectedProduct.dimensions.frameWeight}g ultralight
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  id="btn-toggle-zoom-mode"
                  onClick={() => setIsZoomMode(!isZoomMode)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-wide border backdrop-blur-xl transition-all ${
                    isZoomMode
                      ? 'bg-violet-600 border-violet-400 text-white shadow-md shadow-violet-600/30'
                      : isDark
                      ? 'bg-white/[0.05] border-white/15 text-neutral-300 hover:text-white hover:bg-white/10'
                      : 'bg-white/80 border-neutral-300 text-neutral-800 hover:bg-white'
                  }`}
                  title="Toggle 300% Zoom Loupe Mode"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                  <span>{isZoomMode ? '300% Zoom Active' : 'Enable 300% Loupe'}</span>
                </button>

                <button
                  onClick={() => onOpenTryOn(selectedProduct)}
                  className="p-2 rounded-full border border-white/15 backdrop-blur-xl text-violet-400 hover:bg-violet-500/20 transition-colors"
                  title="Test on Face"
                >
                  <Eye className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Interactive Image Container with 300% Magnifier & Lens Tint Overlay */}
            <div
              ref={imageContainerRef}
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setIsZoomMode(true)}
              className="relative my-auto w-full aspect-[4/3] rounded-xl overflow-hidden cursor-crosshair flex items-center justify-center p-4 select-none group bg-black/10"
            >
              {/* Glasses Main Image */}
              <img
                src={
                  inspectorActiveSpot === 'hinge'
                    ? selectedProduct.hingeImageUrl
                    : inspectorActiveSpot === 'temple'
                    ? selectedProduct.angleImageUrl
                    : selectedProduct.imageUrl
                }
                alt={selectedProduct.name}
                className="w-full h-full object-contain transition-transform duration-300"
                style={{
                  transform: isZoomMode
                    ? `scale(2.2) translate(${-(mouseZoomPos.x - 50) * 0.7}%, ${-(mouseZoomPos.y - 50) * 0.7}%)`
                    : 'scale(1.0)'
                }}
              />

              {/* Dynamic Lens Tint Overlay Effect */}
              <div
                className="absolute inset-0 pointer-events-none transition-colors duration-500 rounded-xl"
                style={{
                  backgroundColor: currentTintData.colorHex,
                  mixBlendMode: 'multiply',
                  opacity: selectedLensTint === 'Clear Anti-Reflective' ? 0.08 : 0.45
                }}
              />

              {/* Live Laser Engraving Simulation on Temple */}
              {engravingText.trim() && (
                <div
                  className="absolute bottom-6 left-8 px-2.5 py-0.5 rounded text-[10px] font-mono tracking-widest uppercase border border-amber-500/40 pointer-events-none backdrop-blur-md shadow-sm"
                  style={{
                    backgroundColor: isDark ? 'rgba(0,0,0,0.75)' : 'rgba(255,255,255,0.85)',
                    color: currentColor.hex === '#1C1C1E' ? '#E5E5E5' : '#D4AF37'
                  }}
                >
                  <span className="text-[8px] text-amber-400 mr-1 font-bold">LASER:</span>
                  {engravingText}
                </div>
              )}

              {/* Inspector Hotspot Pins (When not actively zooming) */}
              {!isZoomMode &&
                INSPECTOR_SPOTS.map((spot) => (
                  <button
                    key={spot.id}
                    onClick={() => setInspectorActiveSpot(spot.id as any)}
                    style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 group/pin flex items-center justify-center`}
                  >
                    <span className="relative flex h-6 w-6">
                      <span
                        className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                          inspectorActiveSpot === spot.id ? 'bg-amber-400' : 'bg-violet-400'
                        }`}
                      />
                      <span
                        className={`relative inline-flex rounded-full h-6 w-6 items-center justify-center text-[10px] font-bold text-black ${
                          inspectorActiveSpot === spot.id ? 'bg-amber-400 shadow-lg' : 'bg-white'
                        }`}
                      >
                        +
                      </span>
                    </span>

                    {/* Tooltip on Pin */}
                    <div className="absolute bottom-8 left-1/2 -translate-x-1/2 opacity-0 group-hover/pin:opacity-100 transition-opacity bg-black/90 backdrop-blur-md border border-white/10 text-white text-[11px] px-2.5 py-1 rounded shadow-xl whitespace-nowrap pointer-events-none z-30 font-medium">
                      {spot.label}
                    </div>
                  </button>
                ))}

              {/* Magnifier Loupe Ring indicator */}
              {isZoomMode && (
                <div
                  className="absolute pointer-events-none border-2 border-amber-400/80 rounded-full w-28 h-28 -translate-x-1/2 -translate-y-1/2 shadow-2xl backdrop-brightness-110 z-30"
                  style={{
                    left: `${mouseZoomPos.x}%`,
                    top: `${mouseZoomPos.y}%`
                  }}
                >
                  <div className="absolute top-1 left-1 bg-black/75 backdrop-blur-md text-amber-400 text-[9px] font-mono px-1.5 py-0.5 rounded">
                    300% MACRO
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Inspection Details Card */}
            <div
              className={`p-4 rounded-xl border z-20 flex flex-wrap items-center justify-between gap-3 backdrop-blur-xl ${
                isDark
                  ? 'bg-white/[0.04] border-white/10 text-neutral-200'
                  : 'bg-white/80 border-white/60 text-neutral-900'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center justify-center">
                  <Maximize2 className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold font-sans">
                    Inspecting:{' '}
                    {INSPECTOR_SPOTS.find((s) => s.id === inspectorActiveSpot)?.label || 'Detail'}
                  </div>
                  <div className="text-[11px] text-neutral-400">
                    {INSPECTOR_SPOTS.find((s) => s.id === inspectorActiveSpot)?.desc}
                  </div>
                </div>
              </div>

              {/* Hotspot Quick Selectors */}
              <div className="flex items-center gap-1.5">
                {INSPECTOR_SPOTS.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setInspectorActiveSpot(s.id as any)}
                    className={`px-3 py-1 rounded-full text-[11px] font-medium transition-all ${
                      inspectorActiveSpot === s.id
                        ? 'bg-amber-400 text-black font-bold shadow-sm'
                        : isDark
                        ? 'bg-white/5 border border-white/10 text-neutral-300 hover:text-white hover:bg-white/10'
                        : 'bg-white text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    {s.label.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Customization Controls & Configuration Panel (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          <div
            className={`p-6 sm:p-7 rounded-2xl border transition-all backdrop-blur-xl ${
              isDark
                ? 'bg-white/[0.03] border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.6)]'
                : 'bg-white/70 border-white/60 shadow-xl'
            }`}
          >
            {/* Header & Title */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 dark:border-white/10">
              <div>
                <h3 className="font-extrabold text-xl font-sans">{selectedProduct.name}</h3>
                <p className="text-xs text-neutral-400 font-mono mt-0.5">
                  Bespoke Studio Build • {selectedProduct.category}
                </p>
              </div>
              <div className="text-right">
                <span className="text-2xl font-black font-sans text-amber-400">
                  ${calculatedTotal}
                </span>
                <div className="text-[10px] text-neutral-400">Complete Custom Build</div>
              </div>
            </div>

            {/* Customizer Option 1: Frame Finish Color */}
            <div className="mt-5">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center justify-between">
                <span>1. Frame Alloy & Acetate Finish</span>
                <span className="text-neutral-200 dark:text-neutral-100 font-medium font-sans lowercase">
                  {currentColor.name}
                </span>
              </label>

              <div className="mt-2.5 grid grid-cols-2 sm:grid-cols-4 gap-2">
                {selectedProduct.colors.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedColorId(c.id)}
                    className={`p-2 rounded-xl border flex flex-col items-center gap-1.5 transition-all ${
                      selectedColorId === c.id
                        ? isDark
                          ? 'border-amber-400 bg-white/10 shadow-sm'
                          : 'border-neutral-900 bg-neutral-100 shadow-sm'
                        : isDark
                        ? 'border-white/10 hover:border-white/20 bg-white/[0.02]'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <span
                      className="w-5 h-5 rounded-full border border-neutral-500 shadow-xs"
                      style={{ backgroundColor: c.hex }}
                    />
                    <span className="text-[10px] font-medium text-center truncate max-w-full">
                      {c.name.split(' ')[0]}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Customizer Option 2: Precision Lens Tint & Coatings */}
            <div className="mt-6">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center justify-between">
                <span>2. Optical Coating & Lens Tint</span>
                <span className="text-amber-400 font-mono text-[11px]">
                  +${currentTintData.priceDelta}
                </span>
              </label>

              <div className="mt-2.5 space-y-2">
                {LENS_TINTS_DATA.map((tint) => (
                  <button
                    key={tint.name}
                    onClick={() => setSelectedLensTint(tint.name as LensTint)}
                    className={`w-full p-3 rounded-xl border flex items-center justify-between text-left transition-all backdrop-blur-xl ${
                      selectedLensTint === tint.name
                        ? isDark
                          ? 'border-violet-400 bg-violet-600/20 shadow-md shadow-violet-600/10'
                          : 'border-violet-600 bg-violet-50'
                        : isDark
                        ? 'border-white/10 hover:border-white/20 bg-white/[0.02]'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className="w-4 h-4 rounded-full border border-neutral-400"
                        style={{ backgroundColor: tint.colorHex }}
                      />
                      <div>
                        <div className="font-semibold text-xs">{tint.name}</div>
                        <div className="text-[10px] text-neutral-400">{tint.subtitle}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded font-mono bg-white/10 text-neutral-300">
                        {tint.badge}
                      </span>
                      {selectedLensTint === tint.name && (
                        <Check className="w-4 h-4 text-violet-400" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Customizer Option 3: Prescription Type */}
            <div className="mt-6">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                3. Prescription / Lens Function
              </label>
              <div className="mt-2.5 grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(
                  [
                    'Non-Prescription (Plano)',
                    'Digital Blue Light Filter',
                    'Single Vision (Distance/Reading)',
                    'Progressive Multifocal'
                  ] as RxType[]
                ).map((rx) => (
                  <button
                    key={rx}
                    onClick={() => setSelectedRx(rx)}
                    className={`p-2.5 rounded-xl border text-left flex flex-col justify-between gap-1 transition-all backdrop-blur-xl ${
                      selectedRx === rx
                        ? isDark
                          ? 'border-amber-400 bg-white/10'
                          : 'border-neutral-900 bg-neutral-100'
                        : isDark
                        ? 'border-white/10 hover:border-white/20 bg-white/[0.02]'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <span className="text-xs font-semibold">{rx.split(' (')[0]}</span>
                    <span className="text-[10px] font-mono text-neutral-400">
                      {rxPriceMap[rx] === 0 ? 'Included' : `+$${rxPriceMap[rx]}`}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Customizer Option 4: Custom Laser Temple Engraving */}
            <div className="mt-6">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center justify-between">
                <span>4. Laser Monogram Engraving</span>
                <span className="text-[10px] font-mono text-neutral-400">
                  {engravingText.trim() ? '+$25' : 'Optional'}
                </span>
              </label>

              <div className="mt-2 flex items-center gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    maxLength={12}
                    value={engravingText}
                    onChange={(e) => setEngravingText(e.target.value.toUpperCase())}
                    placeholder="E.G., M. STERLING"
                    className={`w-full px-3.5 py-2 rounded-xl text-xs font-mono tracking-widest uppercase border focus:outline-none focus:ring-1 focus:ring-amber-400 transition-colors backdrop-blur-xl ${
                      isDark
                        ? 'bg-white/[0.04] border-white/15 text-neutral-100 placeholder-neutral-500'
                        : 'bg-neutral-50 border-neutral-300 text-neutral-900 placeholder-neutral-400'
                    }`}
                  />
                  <Type className="w-3.5 h-3.5 absolute right-3 top-2.5 text-neutral-500" />
                </div>
                {engravingText && (
                  <button
                    onClick={() => setEngravingText('')}
                    className="text-xs text-neutral-400 hover:text-white"
                  >
                    Clear
                  </button>
                )}
              </div>
              <p className="text-[10px] text-neutral-400 mt-1">
                Precision laser-etched onto inner left titanium arm. Max 12 characters.
              </p>
            </div>

            {/* Customizer Option 5: Hinge Finish */}
            <div className="mt-6">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                5. Barrel Hinge Hardware Finish
              </label>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {(['Brushed Platinum', 'Matte Black Titanium', '24k Gold Ion'] as const).map(
                  (h) => (
                    <button
                      key={h}
                      onClick={() => setHingeFinish(h)}
                      className={`p-2 rounded-xl border text-center text-xs font-medium transition-all backdrop-blur-xl ${
                        hingeFinish === h
                          ? isDark
                            ? 'border-amber-400 bg-white/10 font-bold'
                            : 'border-neutral-900 bg-neutral-100 font-bold'
                          : isDark
                          ? 'border-white/10 bg-white/[0.02] text-neutral-400 hover:border-white/20'
                          : 'border-neutral-200 bg-white text-neutral-600'
                      }`}
                    >
                      <div className="text-[11px] truncate">{h}</div>
                      <div className="text-[9px] font-mono text-neutral-400">
                        {hingePriceMap[h] === 0 ? 'Standard' : `+$${hingePriceMap[h]}`}
                      </div>
                    </button>
                  )
                )}
              </div>
            </div>

            {/* Add to Bag Button */}
            <div className="mt-8 pt-5 border-t border-white/10 dark:border-white/10 flex flex-col gap-3">
              <button
                id="btn-add-custom-to-cart"
                onClick={() =>
                  onAddToCart({
                    product: selectedProduct,
                    color: currentColor,
                    lensTint: selectedLensTint,
                    rxType: selectedRx,
                    engravingText: engravingText.trim(),
                    hingeFinish: hingeFinish,
                    totalPrice: calculatedTotal
                  })
                }
                className={`w-full py-4 rounded-xl font-bold text-sm tracking-wide transition-all duration-300 flex items-center justify-center gap-2.5 shadow-xl border ${
                  isDark
                    ? 'bg-white text-neutral-950 hover:bg-neutral-100 hover:scale-[1.02] border-white/40 shadow-violet-500/20'
                    : 'bg-neutral-950 text-white hover:bg-neutral-800 hover:scale-[1.02] border-black shadow-neutral-900/20'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add Customized Pair to Bag — ${calculatedTotal}</span>
              </button>

              <div className="flex items-center justify-center gap-4 text-[11px] text-neutral-400">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Lifetime Hinge Guarantee
                </span>
                <span>•</span>
                <span>30-Day Risk-Free Trial</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
