import React, { useState, useEffect } from 'react';
import {
  Sun,
  Moon,
  ShoppingBag,
  Heart,
  Sliders,
  Compass,
  Sparkles,
  Menu,
  X,
  Eye
} from 'lucide-react';
import { ThemeMode } from '../types';

interface HeaderProps {
  theme: ThemeMode;
  onToggleTheme: () => void;
  cartCount: number;
  onOpenCart: () => void;
  wishlistCount: number;
  onOpenWishlist: () => void;
  onOpenVirtualTryOn: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  theme,
  onToggleTheme,
  cartCount,
  onOpenCart,
  wishlistCount,
  onOpenWishlist,
  onOpenVirtualTryOn
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isDark = theme === 'dark';

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -80;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <header
      id="main-navigation-header"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? isDark
            ? 'bg-black/50 backdrop-blur-2xl border-b border-white/10 shadow-[0_10px_30px_rgba(0,0,0,0.5)] py-3.5'
            : 'bg-white/70 backdrop-blur-2xl border-b border-white/40 shadow-[0_10px_25px_rgba(0,0,0,0.05)] py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo & Brand */}
          <a
            id="brand-logo-link"
            href="#hero"
            onClick={(e) => {
              e.preventDefault();
              scrollToSection('hero');
            }}
            className="flex items-center gap-3 group focus:outline-none"
          >
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center font-extrabold text-sm tracking-wider transition-all duration-300 shadow-md ${
                isDark
                  ? 'bg-white/10 text-white border border-white/20 backdrop-blur-md group-hover:bg-violet-600 group-hover:border-violet-500'
                  : 'bg-neutral-900 text-neutral-100 group-hover:bg-violet-700'
              }`}
            >
              MGW
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-lg sm:text-xl tracking-tight leading-none font-sans">
                MGW
              </span>
              <span
                className={`text-[10px] tracking-[0.2em] uppercase font-medium mt-0.5 ${
                  isDark ? 'text-neutral-400' : 'text-neutral-600'
                }`}
              >
                Men's Glasses Wear
              </span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-2 p-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-xl">
            <button
              id="nav-link-collection"
              onClick={() => scrollToSection('gallery-section')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                isDark
                  ? 'text-neutral-300 hover:text-white hover:bg-white/10'
                  : 'text-neutral-700 hover:text-neutral-900 hover:bg-black/5'
              }`}
            >
              Collection
            </button>
            <button
              id="nav-link-zoom-gallery"
              onClick={() => scrollToSection('gallery-section')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide flex items-center gap-1.5 transition-all ${
                isDark
                  ? 'text-neutral-300 hover:text-white hover:bg-white/10'
                  : 'text-neutral-700 hover:text-neutral-900 hover:bg-black/5'
              }`}
            >
              <span>Zoom Gallery</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-violet-500/20 text-violet-300 font-mono border border-violet-500/30">
                Macro
              </span>
            </button>
            <button
              id="nav-link-customizer"
              onClick={() => scrollToSection('customizer-section')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                isDark
                  ? 'text-neutral-300 hover:text-white hover:bg-white/10'
                  : 'text-neutral-700 hover:text-neutral-900 hover:bg-black/5'
              }`}
            >
              Customizer
            </button>
            <button
              id="nav-link-face-finder"
              onClick={() => scrollToSection('frame-finder-section')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide flex items-center gap-1.5 transition-all ${
                isDark
                  ? 'text-neutral-300 hover:text-white hover:bg-white/10'
                  : 'text-neutral-700 hover:text-neutral-900 hover:bg-black/5'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              <span>Face Finder</span>
            </button>
            <button
              id="nav-link-reviews"
              onClick={() => scrollToSection('reviews-section')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all ${
                isDark
                  ? 'text-neutral-300 hover:text-white hover:bg-white/10'
                  : 'text-neutral-700 hover:text-neutral-900 hover:bg-black/5'
              }`}
            >
              Reviews
            </button>
          </nav>

          {/* Action Icons & Theme Switcher */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            {/* Virtual Try-on Trigger */}
            <button
              id="btn-nav-tryon"
              onClick={onOpenVirtualTryOn}
              className={`hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-wide border transition-all ${
                isDark
                  ? 'border-violet-500/30 text-violet-300 bg-violet-950/30 hover:bg-violet-900/40 backdrop-blur-md shadow-sm'
                  : 'border-violet-300 text-violet-800 bg-violet-50 hover:bg-violet-100 shadow-sm'
              }`}
              title="Virtual Try-On Simulator"
            >
              <Eye className="w-3.5 h-3.5 text-violet-400" />
              <span>Try On</span>
            </button>

            {/* Dark / Light Mode Switcher */}
            <button
              id="btn-theme-toggle"
              onClick={onToggleTheme}
              className={`p-2 sm:px-3 sm:py-1.5 rounded-full flex items-center gap-1.5 transition-all border ${
                isDark
                  ? 'bg-white/[0.06] border-white/15 text-amber-300 hover:bg-white/10 backdrop-blur-md'
                  : 'bg-white/80 border-white/60 text-neutral-800 hover:bg-white shadow-sm backdrop-blur-md'
              }`}
              title={`Switch to ${isDark ? 'Pearl Glass (Light)' : 'Frosted Obsidian (Dark)'} Mode`}
              aria-label="Toggle Theme Mode"
            >
              {isDark ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span className="hidden md:inline text-xs font-medium text-neutral-200">
                    Pearl
                  </span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-neutral-700" />
                  <span className="hidden md:inline text-xs font-medium text-neutral-700">
                    Obsidian
                  </span>
                </>
              )}
            </button>

            {/* Wishlist Button */}
            <button
              id="btn-wishlist-toggle"
              onClick={onOpenWishlist}
              className={`relative p-2 rounded-full transition-colors border ${
                isDark
                  ? 'bg-white/[0.04] border-white/10 text-neutral-300 hover:text-white hover:bg-white/10 backdrop-blur-md'
                  : 'bg-white/80 border-white/60 text-neutral-700 hover:text-neutral-900 hover:bg-white backdrop-blur-md shadow-xs'
              }`}
              title="View Wishlist"
              aria-label="Wishlist"
            >
              <Heart className="w-4 h-4" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center shadow-md">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Shopping Bag Button */}
            <button
              id="btn-cart-toggle"
              onClick={onOpenCart}
              className={`relative flex items-center gap-2 px-3.5 py-1.5 rounded-full font-semibold text-xs tracking-wide transition-all border ${
                isDark
                  ? 'bg-white/90 text-neutral-950 hover:bg-white border-white/30 shadow-[0_4px_15px_rgba(255,255,255,0.15)] backdrop-blur-md'
                  : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black shadow-sm'
              }`}
              title="Open Shopping Bag"
              aria-label="Shopping Bag"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Bag</span>
              {cartCount > 0 && (
                <span
                  className={`w-4 h-4 rounded-full text-[10px] font-bold flex items-center justify-center ${
                    isDark ? 'bg-neutral-950 text-white' : 'bg-white text-neutral-900'
                  }`}
                >
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              id="btn-mobile-menu"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`p-2 rounded-lg lg:hidden transition-colors border ${
                isDark
                  ? 'bg-white/[0.05] border-white/10 text-neutral-300 hover:text-white backdrop-blur-md'
                  : 'bg-white/80 border-white/60 text-neutral-700 hover:text-neutral-900 backdrop-blur-md'
              }`}
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div
            id="mobile-nav-menu"
            className={`lg:hidden mt-4 p-5 rounded-2xl border transition-all animate-fadeIn backdrop-blur-2xl shadow-2xl ${
              isDark
                ? 'bg-black/75 border-white/10 text-neutral-200'
                : 'bg-white/90 border-white/60 text-neutral-900 shadow-xl'
            }`}
          >
            <div className="flex flex-col space-y-3 font-medium text-sm">
              <button
                onClick={() => scrollToSection('hero')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-500/10 transition-colors"
              >
                Hero Showcase
              </button>
              <button
                onClick={() => scrollToSection('gallery-section')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-500/10 transition-colors flex items-center justify-between"
              >
                <span>Product Gallery</span>
                <span className="text-xs text-purple-400 font-mono font-bold">Zoom-On-Scroll</span>
              </button>
              <button
                onClick={() => scrollToSection('customizer-section')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-500/10 transition-colors"
              >
                Interactive Customizer & Inspector
              </button>
              <button
                onClick={() => scrollToSection('frame-finder-section')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-500/10 transition-colors flex items-center gap-2"
              >
                <Compass className="w-4 h-4 text-amber-500" />
                <span>3-Step Face Shape Finder</span>
              </button>
              <button
                onClick={() => scrollToSection('reviews-section')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-500/10 transition-colors"
              >
                Customer Reviews
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenVirtualTryOn();
                }}
                className="text-left py-2 px-3 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20 font-semibold"
              >
                Launch Virtual Try-On
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
