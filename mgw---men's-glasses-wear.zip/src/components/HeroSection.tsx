import React from 'react';
import { ArrowRight, Compass, ShieldCheck, Sparkles, SlidersHorizontal, Eye, ChevronDown } from 'lucide-react';
import { ThemeMode } from '../types';

interface HeroSectionProps {
  theme: ThemeMode;
  onExploreCollection: () => void;
  onOpenFaceFinder: () => void;
  onOpenCustomizer: () => void;
  onOpenPromptModal: () => void;
  onOpenTryOn: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  theme,
  onExploreCollection,
  onOpenFaceFinder,
  onOpenCustomizer,
  onOpenPromptModal,
  onOpenTryOn
}) => {
  const isDark = theme === 'dark';

  const scrollToGallery = () => {
    const el = document.getElementById('gallery-section');
    if (el) {
      const yOffset = -70;
      const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-[92vh] lg:min-h-screen flex flex-col justify-between pt-28 pb-12 sm:pt-36 sm:pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto overflow-hidden z-10"
    >
      {/* Top Banner Tag */}
      <div className="flex flex-col items-center text-center mt-4 sm:mt-8">
        <div
          className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase mb-6 backdrop-blur-xl border transition-all ${
            isDark
              ? 'bg-white/[0.06] border-white/15 text-amber-300 shadow-[0_4px_20px_rgba(0,0,0,0.3)]'
              : 'bg-white/80 border-white/60 text-amber-900 shadow-sm'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          <span>2026 Bespoke Titanium & Acetate Edition</span>
        </div>

        {/* Main Branding & Tagline */}
        <h1
          id="hero-title"
          className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-extrabold tracking-tighter uppercase font-sans leading-none select-none drop-shadow-md"
        >
          <span
            className={`inline-block ${
              isDark
                ? 'text-white'
                : 'text-neutral-950'
            }`}
          >
            MGW
          </span>
        </h1>

        <p
          className={`text-sm sm:text-base md:text-lg uppercase tracking-[0.35em] font-medium mt-2 sm:mt-3 ${
            isDark ? 'text-neutral-400' : 'text-neutral-600'
          }`}
        >
          Men’s Glasses Wear
        </p>

        <h2
          id="hero-tagline"
          className={`text-2xl sm:text-4xl md:text-5xl font-serif italic font-normal mt-5 sm:mt-7 max-w-4xl tracking-tight leading-tight ${
            isDark ? 'text-neutral-100' : 'text-neutral-900'
          }`}
        >
          "Engineered Precision.{' '}
          <span className="underline decoration-violet-500/70 decoration-2 underline-offset-8 text-amber-400">
            Timeless
          </span>{' '}
          Men's Eyewear."
        </h2>

        <p
          className={`mt-4 sm:mt-6 text-sm sm:text-base max-w-2xl text-center leading-relaxed font-normal ${
            isDark ? 'text-neutral-300' : 'text-neutral-700'
          }`}
        >
          Sculpted from aerospace-grade Japanese Beta-Titanium and hand-finished Mazzucchelli Italian acetate.
          Experience featherweight structural balance, multi-axis micro barrel hinges, and optical clarity tailored to masculine face architecture.
        </p>

        {/* Call to Actions */}
        <div className="mt-8 sm:mt-10 flex flex-wrap items-center justify-center gap-3.5 sm:gap-5">
          {/* Primary CTA: Prominent "Explore Collection" */}
          <button
            id="btn-hero-explore-collection"
            onClick={onExploreCollection}
            className={`group flex items-center gap-3 px-7 py-4 rounded-full font-bold text-sm sm:text-base tracking-wide transition-all duration-300 shadow-xl border ${
              isDark
                ? 'bg-white text-neutral-950 hover:bg-neutral-100 hover:scale-105 border-white/40 shadow-violet-500/20'
                : 'bg-neutral-950 text-white hover:bg-neutral-800 hover:scale-105 border-black shadow-neutral-900/20'
            }`}
          >
            <span>Explore Collection</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Secondary CTAs */}
          <button
            id="btn-hero-face-finder"
            onClick={onOpenFaceFinder}
            className={`flex items-center gap-2.5 px-6 py-4 rounded-full font-semibold text-sm sm:text-base tracking-wide backdrop-blur-xl border transition-all ${
              isDark
                ? 'bg-white/[0.05] border-white/15 text-neutral-200 hover:bg-white/10 hover:border-white/25 shadow-lg'
                : 'bg-white/80 border-white/60 text-neutral-900 hover:bg-white hover:border-neutral-300 shadow-sm'
            }`}
          >
            <Compass className="w-4 h-4 text-amber-400" />
            <span>Face Shape Finder</span>
          </button>

          <button
            id="btn-hero-virtual-tryon"
            onClick={onOpenTryOn}
            className={`flex items-center gap-2 px-6 py-4 rounded-full font-semibold text-sm sm:text-base tracking-wide backdrop-blur-xl border transition-all ${
              isDark
                ? 'bg-violet-600/20 border-violet-500/40 text-violet-300 hover:bg-violet-600/30 hover:border-violet-400 shadow-lg shadow-violet-500/10'
                : 'bg-violet-50 border-violet-200 text-violet-900 hover:bg-violet-100'
            }`}
          >
            <Eye className="w-4 h-4 text-violet-400" />
            <span>Virtual Fit</span>
          </button>
        </div>
      </div>

      {/* Craft Badges / Pillars Row */}
      <div className="mt-12 sm:mt-16 pt-8 border-t border-white/10 dark:border-white/10 grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 text-left">
        <div
          className={`p-4 sm:p-5 rounded-2xl border backdrop-blur-xl transition-all ${
            isDark
              ? 'bg-white/[0.03] border-white/10 hover:border-white/20 hover:bg-white/[0.06] shadow-xl'
              : 'bg-white/70 border-white/60 hover:border-white hover:bg-white/90 shadow-sm'
          }`}
        >
          <div className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
            Material Spec
          </div>
          <div className="font-bold text-sm sm:text-base mt-1">Grade-5 Beta-Titanium</div>
          <div className="text-xs text-neutral-400 mt-0.5">
            Surgical purity, anti-corrosive
          </div>
        </div>

        <div
          className={`p-4 sm:p-5 rounded-2xl border backdrop-blur-xl transition-all ${
            isDark
              ? 'bg-white/[0.03] border-white/10 hover:border-white/20 hover:bg-white/[0.06] shadow-xl'
              : 'bg-white/70 border-white/60 hover:border-white hover:bg-white/90 shadow-sm'
          }`}
        >
          <div className="text-xs font-mono font-bold text-violet-400 uppercase tracking-wider">
            Weight Precision
          </div>
          <div className="font-bold text-sm sm:text-base mt-1">Under 14 Grams</div>
          <div className="text-xs text-neutral-400 mt-0.5">
            Featherlight all-day comfort
          </div>
        </div>

        <div
          className={`p-4 sm:p-5 rounded-2xl border backdrop-blur-xl transition-all ${
            isDark
              ? 'bg-white/[0.03] border-white/10 hover:border-white/20 hover:bg-white/[0.06] shadow-xl'
              : 'bg-white/70 border-white/60 hover:border-white hover:bg-white/90 shadow-sm'
          }`}
        >
          <div className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
            Mechanical Durability
          </div>
          <div className="font-bold text-sm sm:text-base mt-1">50,000 Cycle Hinge</div>
          <div className="text-xs text-neutral-400 mt-0.5">
            Lifetime structural warranty
          </div>
        </div>

        <div
          className={`p-4 sm:p-5 rounded-2xl border backdrop-blur-xl transition-all ${
            isDark
              ? 'bg-white/[0.03] border-white/10 hover:border-white/20 hover:bg-white/[0.06] shadow-xl'
              : 'bg-white/70 border-white/60 hover:border-white hover:bg-white/90 shadow-sm'
          }`}
        >
          <div className="text-xs font-mono font-bold text-sky-400 uppercase tracking-wider">
            Optics Coating
          </div>
          <div className="font-bold text-sm sm:text-base mt-1">Diamond Hydrophobic</div>
          <div className="text-xs text-neutral-400 mt-0.5">
            Anti-reflective & UV400 shield
          </div>
        </div>
      </div>

      {/* Scroll Down Hint */}
      <div className="mt-8 flex justify-center">
        <button
          id="btn-scroll-indicator"
          onClick={scrollToGallery}
          className={`flex items-center gap-2 text-xs font-medium tracking-widest uppercase transition-colors ${
            isDark ? 'text-neutral-400 hover:text-white' : 'text-neutral-600 hover:text-neutral-900'
          }`}
          aria-label="Scroll to Gallery"
        >
          <span>Scroll to Inspect Frames</span>
          <ChevronDown className="w-4 h-4 animate-bounce" />
        </button>
      </div>
    </section>
  );
};
