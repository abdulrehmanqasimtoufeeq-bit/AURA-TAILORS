import React, { useState } from 'react';
import { Product, ThemeMode, FrameColor } from '../types';
import {
  X,
  ShoppingBag,
  SlidersHorizontal,
  Eye,
  Heart,
  ShieldCheck,
  Check,
  Sparkles,
  Maximize2,
  Compass
} from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  initialColorId?: string;
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
  onAddToCart: (product: Product, color: FrameColor) => void;
  onOpenCustomizer: (product: Product, colorId?: string) => void;
  onOpenTryOn: (product: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  initialColorId,
  isOpen,
  onClose,
  theme,
  onAddToCart,
  onOpenCustomizer,
  onOpenTryOn,
  isWishlisted,
  onToggleWishlist
}) => {
  if (!isOpen || !product) return null;
  const isDark = theme === 'dark';

  const [selectedColorId, setSelectedColorId] = useState(
    initialColorId || product.colors[0].id
  );
  const [activeImageKey, setActiveImageKey] = useState<'main' | 'angle' | 'hinge' | 'model'>('main');

  const currentColor =
    product.colors.find((c) => c.id === selectedColorId) || product.colors[0];

  const getActiveImage = () => {
    switch (activeImageKey) {
      case 'angle':
        return product.angleImageUrl;
      case 'hinge':
        return product.hingeImageUrl;
      case 'model':
        return product.modelImageUrl;
      default:
        return product.imageUrl;
    }
  };

  return (
    <div
      id="product-detail-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="product-detail-card"
        className={`relative w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-2xl border p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.8)] backdrop-blur-2xl transition-all ${
          isDark ? 'bg-[#0f0f15]/90 border-white/15 text-white' : 'bg-white/90 border-white/60 text-neutral-900'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close & Wishlist Top Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 dark:border-white/10">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-full text-[11px] font-mono font-bold uppercase bg-amber-500/20 text-amber-400 border border-amber-500/30 backdrop-blur-xl">
              {product.series}
            </span>
            <span className="text-xs text-neutral-400 font-mono">
              Weight: {product.dimensions.frameWeight}g
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleWishlist(product.id)}
              className={`p-2 rounded-xl border backdrop-blur-xl transition-all ${
                isWishlisted
                  ? 'bg-rose-500 text-white border-rose-500 shadow-md'
                  : 'border-white/15 text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
              title="Save to Wishlist"
            >
              <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl border border-transparent hover:border-white/15 text-neutral-400 hover:text-white hover:bg-white/10 transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal 2-Column Content */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Image Viewer & Angle Thumbnails (7 Cols) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <div
              className={`relative aspect-[4/3] rounded-2xl overflow-hidden border flex items-center justify-center p-6 backdrop-blur-xl ${
                isDark ? 'bg-white/[0.02] border-white/10' : 'bg-white/80 border-white/60 shadow-sm'
              }`}
            >
              <img
                src={getActiveImage()}
                alt={product.name}
                className="w-full h-full object-contain transition-transform duration-500 hover:scale-110 drop-shadow-[0_10px_20px_rgba(0,0,0,0.5)]"
              />
            </div>

            {/* Thumbnail Angle Selectors */}
            <div className="grid grid-cols-4 gap-2">
              {[
                { key: 'main', label: 'Front View', img: product.imageUrl },
                { key: 'angle', label: '45° Angle', img: product.angleImageUrl },
                { key: 'hinge', label: 'Hinge Macro', img: product.hingeImageUrl },
                { key: 'model', label: 'On Model', img: product.modelImageUrl }
              ].map((t) => (
                <button
                  key={t.key}
                  onClick={() => setActiveImageKey(t.key as any)}
                  className={`p-1.5 rounded-xl border text-center transition-all backdrop-blur-xl ${
                    activeImageKey === t.key
                      ? 'border-amber-400 ring-1 ring-amber-400 bg-amber-400/10'
                      : isDark
                      ? 'border-white/10 bg-white/[0.02] hover:border-white/20'
                      : 'border-white/60 bg-white/60 hover:border-neutral-300'
                  }`}
                >
                  <img
                    src={t.img}
                    alt={t.label}
                    className="w-full h-12 object-cover rounded-lg mb-1"
                  />
                  <span className="text-[10px] font-mono block truncate text-neutral-400">
                    {t.label}
                  </span>
                </button>
              ))}
            </div>

            {/* Structural Dimension Specs */}
            <div
              className={`p-4 rounded-xl border text-xs font-mono grid grid-cols-4 gap-2 text-center backdrop-blur-xl ${
                isDark ? 'bg-white/[0.03] border-white/10' : 'bg-white/80 border-white/60'
              }`}
            >
              <div>
                <div className="text-neutral-400 text-[10px]">LENS WIDTH</div>
                <div className="font-bold text-sm text-amber-400">
                  {product.dimensions.lensWidth} mm
                </div>
              </div>
              <div>
                <div className="text-neutral-400 text-[10px]">BRIDGE</div>
                <div className="font-bold text-sm text-amber-400">
                  {product.dimensions.bridgeWidth} mm
                </div>
              </div>
              <div>
                <div className="text-neutral-400 text-[10px]">TEMPLE</div>
                <div className="font-bold text-sm text-amber-400">
                  {product.dimensions.templeLength} mm
                </div>
              </div>
              <div>
                <div className="text-neutral-400 text-[10px]">WEIGHT</div>
                <div className="font-bold text-sm text-amber-400">
                  {product.dimensions.frameWeight} g
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Specs, Finish Swatches & CTAs (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono text-neutral-400 uppercase">
                {product.category} Silhouette • {product.material}
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-sans mt-1">
                {product.name}
              </h2>
              <div className="text-2xl font-black font-sans text-amber-400 mt-2">
                ${product.price}
              </div>

              <p
                className={`mt-3 text-xs sm:text-sm leading-relaxed ${
                  isDark ? 'text-neutral-300' : 'text-neutral-700'
                }`}
              >
                {product.description}
              </p>

              {/* Craft Details Checklist */}
              <div className="mt-4 space-y-2 text-xs">
                {product.craftDetails.map((detail, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-neutral-300">
                    <Check className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                    <span>{detail}</span>
                  </div>
                ))}
              </div>

              {/* Best For Face Shapes */}
              <div className="mt-5">
                <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1.5 font-mono">
                  Optimal Face Geometry:
                </span>
                <div className="flex flex-wrap items-center gap-1.5">
                  {product.bestForFaceShapes.map((shape) => (
                    <span
                      key={shape}
                      className="px-2.5 py-1 rounded-full text-[11px] font-mono bg-violet-500/10 text-violet-300 border border-violet-500/20 backdrop-blur-xl"
                    >
                      {shape} Face
                    </span>
                  ))}
                </div>
              </div>

              {/* Color Finish Selection */}
              <div className="mt-5">
                <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center justify-between mb-2 font-mono">
                  <span>Selected Finish:</span>
                  <span className="text-neutral-200 font-sans font-medium">{currentColor.name}</span>
                </span>
                <div className="flex items-center gap-2">
                  {product.colors.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => setSelectedColorId(c.id)}
                      className={`w-8 h-8 rounded-full border-2 transition-all ${
                        selectedColorId === c.id
                          ? 'ring-2 ring-amber-400 scale-110 border-white'
                          : 'border-white/30 hover:scale-105'
                      }`}
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-8 pt-5 border-t border-white/10 dark:border-white/10 space-y-2.5">
              <button
                id="btn-modal-add-to-cart"
                onClick={() => {
                  onAddToCart(product, currentColor);
                  onClose();
                }}
                className={`w-full py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg border ${
                  isDark
                    ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40'
                    : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Bag — ${product.price}</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    onClose();
                    onOpenTryOn(product);
                  }}
                  className={`py-2.5 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all backdrop-blur-xl ${
                    isDark
                      ? 'border-white/15 hover:border-white/30 text-neutral-200 hover:bg-white/10'
                      : 'border-neutral-300 hover:border-neutral-400 text-neutral-700'
                  }`}
                >
                  <Eye className="w-3.5 h-3.5 text-violet-400" />
                  <span>Virtual Try-On</span>
                </button>

                <button
                  onClick={() => {
                    onClose();
                    onOpenCustomizer(product, selectedColorId);
                  }}
                  className={`py-2.5 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all backdrop-blur-xl ${
                    isDark
                      ? 'border-white/15 hover:border-white/30 text-amber-400 hover:bg-white/10'
                      : 'border-neutral-300 hover:border-neutral-400 text-amber-800'
                  }`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>300% Customizer</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
