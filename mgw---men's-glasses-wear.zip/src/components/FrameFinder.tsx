import React, { useState } from 'react';
import {
  Product,
  FaceShape,
  ThemeMode,
  FrameColor
} from '../types';
import {
  Compass,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  RotateCcw,
  SlidersHorizontal,
  Eye,
  Camera,
  Layers,
  ChevronRight
} from 'lucide-react';

interface FrameFinderProps {
  products: Product[];
  theme: ThemeMode;
  onSelectProduct: (product: Product) => void;
  onOpenCustomizer: (product: Product) => void;
  onOpenTryOn: (product: Product) => void;
}

export const FrameFinder: React.FC<FrameFinderProps> = ({
  products,
  theme,
  onSelectProduct,
  onOpenCustomizer,
  onOpenTryOn
}) => {
  const isDark = theme === 'dark';

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [selectedShape, setSelectedShape] = useState<FaceShape | null>('Square');
  const [selectedVibe, setSelectedVibe] = useState<string>('Executive Minimalist');
  const [selectedColorPref, setSelectedColorPref] = useState<string>('Gunmetal Grey');
  const [isScanningFace, setIsScanningFace] = useState<boolean>(false);

  const FACE_SHAPES_DATA = [
    {
      shape: 'Round' as FaceShape,
      title: 'Round Face',
      desc: 'Soft curved cheekbones and jawline with equal width and height.',
      rule: 'Structured rectangular and square angular frames add definition and lengthen features.',
      bestFrames: 'Square, Vanguard, Wayfarer',
      icon: '⭕'
    },
    {
      shape: 'Square' as FaceShape,
      title: 'Square Face',
      desc: 'Strong, prominent jawline with straight vertical cheekbones and wide forehead.',
      rule: 'Curved aviators and round panto frames soften strong angles and create optical balance.',
      bestFrames: 'Panthos Circle, Aeronaut Aviator',
      icon: '⬛'
    },
    {
      shape: 'Oval' as FaceShape,
      title: 'Oval Face',
      desc: 'Balanced proportions with softly rounded jawline and slightly wider cheekbones.',
      rule: 'Universal face geometry. Fits aviators, wayfarers, rimless, and bold geometric frames.',
      bestFrames: 'All Silhouettes, Strata Rimless',
      icon: '🥚'
    },
    {
      shape: 'Heart' as FaceShape,
      title: 'Heart Face',
      desc: 'Broader forehead tapering gently to a sharper pointed chin.',
      rule: 'Bottom-heavy aviators and thin titanium rimless draw gaze downward symmetrically.',
      bestFrames: 'Aeronaut Aviator, Strata Rimless',
      icon: '🔻'
    },
    {
      shape: 'Diamond' as FaceShape,
      title: 'Diamond Face',
      desc: 'Narrow forehead and jawline with high, sculpted dramatic cheekbones.',
      rule: 'Round and panto frames highlight high cheekbones while softening eye width.',
      bestFrames: 'Panthos Circle, Monolith Wayfarer',
      icon: '💎'
    }
  ];

  const STYLE_VIBES = [
    {
      id: 'Executive Minimalist',
      title: 'Executive Minimalist',
      subtitle: 'Titanium clarity for boardrooms, trading floors & clean suits.',
      icon: '👔'
    },
    {
      id: 'Bold Statement',
      title: 'Bold Architectural',
      subtitle: 'Thick hand-buffed 8mm Italian acetate with imposing presence.',
      icon: '🕶️'
    },
    {
      id: 'Ultralight Performance',
      title: 'Zero-Mass Studio',
      subtitle: 'Screwless rimless design under 10 grams for seamless comfort.',
      icon: '🪶'
    },
    {
      id: 'Heritage Classic',
      title: 'Heritage Intellectual',
      subtitle: 'Keyhole bridge panto circles inspired by iconic mid-century design.',
      icon: '📜'
    }
  ];

  const COLOR_PREFERENCES = [
    { name: 'Matte Stealth Black', hex: '#1C1C1E', desc: 'Modern tactical monochrome' },
    { name: 'Gunmetal Grey', hex: '#4A4C50', desc: 'Industrial brushed metal' },
    { name: 'Soft Beige Sand', hex: '#D7C7B2', desc: 'Warm understated luxury' },
    { name: 'Havana Tortoiseshell', hex: '#634832', desc: 'Classic organic warmth' },
    { name: 'Brushed Champagne Gold', hex: '#C5A880', desc: '18k ion plated prestige' }
  ];

  // AI Camera Face Shape Auto-detect simulation
  const runAiFaceScan = () => {
    setIsScanningFace(true);
    setTimeout(() => {
      setSelectedShape('Square');
      setIsScanningFace(false);
      setStep(2);
    }, 1600);
  };

  // Find matching recommendations based on selections
  const matchingProducts = products
    .map((p) => {
      let score = 70;
      if (selectedShape && p.bestForFaceShapes.includes(selectedShape)) {
        score += 24;
      }
      if (selectedVibe.includes('Minimalist') && p.material.includes('Titanium')) {
        score += 5;
      }
      if (selectedVibe.includes('Bold') && p.material.includes('Acetate')) {
        score += 5;
      }
      if (selectedVibe.includes('Zero-Mass') && p.category === 'Rimless') {
        score += 6;
      }
      return { product: p, score: Math.min(score, 99) };
    })
    .sort((a, b) => b.score - a.score);

  return (
    <section
      id="frame-finder-section"
      className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10"
    >
      {/* Section Badge */}
      <div className="flex items-center gap-2.5 mb-2">
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
        <span
          className={`text-xs font-mono font-bold uppercase tracking-widest ${
            isDark ? 'text-emerald-400' : 'text-emerald-800'
          }`}
        >
          Section 04 — Face Architecture Guide
        </span>
      </div>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-white/10 dark:border-white/10">
        <div>
          <h2
            id="frame-finder-title"
            className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight font-sans"
          >
            Frame Finder &{' '}
            <span className="font-serif italic font-normal text-amber-400">Style Guide</span>
          </h2>
          <p
            className={`mt-2 text-sm sm:text-base max-w-2xl ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}
          >
            Optically paired frame recommendations based on facial anatomy, jawline width,
            and personal aesthetic preference.
          </p>
        </div>

        {/* 3-Step Progress Tracker */}
        <div className="flex items-center gap-2 p-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-xl">
          {[1, 2, 3].map((s) => (
            <button
              key={s}
              onClick={() => setStep(s as any)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono font-bold transition-all ${
                step === s
                  ? 'bg-amber-400 text-black shadow-md'
                  : step > s
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                  : isDark
                  ? 'text-neutral-400 hover:text-white hover:bg-white/10'
                  : 'text-neutral-500 hover:text-neutral-900 hover:bg-black/5'
              }`}
            >
              <span>0{s}</span>
              <span className="hidden sm:inline">
                {s === 1 ? 'Face Shape' : s === 2 ? 'Style Vibe' : 'Finish & Color'}
              </span>
            </button>
          ))}
          <button
            onClick={() => setStep(4)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all backdrop-blur-xl ${
              step === 4
                ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                : isDark
                ? 'bg-white/10 text-neutral-300 hover:text-white hover:bg-white/15'
                : 'bg-neutral-200 text-neutral-700 hover:bg-neutral-300'
            }`}
          >
            View Matches ({matchingProducts.length})
          </button>
        </div>
      </div>

      {/* Step Views */}
      <div className="mt-10">
        {/* STEP 1: Face Shape Selector */}
        {step === 1 && (
          <div className="animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <h3 className="text-xl font-bold font-sans">Step 1: Select Your Face Shape</h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Choose the shape closest to your facial structure or use our AI facial scan.
                </p>
              </div>

              <button
                id="btn-run-ai-facescan"
                onClick={runAiFaceScan}
                disabled={isScanningFace}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold border transition-all backdrop-blur-xl ${
                  isScanningFace
                    ? 'bg-violet-600/50 border-violet-400 text-white'
                    : isDark
                    ? 'bg-white/[0.05] border-violet-500/40 text-violet-300 hover:bg-violet-500/20'
                    : 'bg-violet-50 border-violet-200 text-violet-900 hover:bg-violet-100'
                }`}
              >
                <Camera className={`w-4 h-4 ${isScanningFace ? 'animate-spin' : ''}`} />
                <span>{isScanningFace ? 'Analyzing Geometry...' : 'AI Auto-Detect Face'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {FACE_SHAPES_DATA.map((item) => (
                <div
                  key={item.shape}
                  id={`face-shape-${item.shape.toLowerCase()}`}
                  onClick={() => setSelectedShape(item.shape)}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all duration-300 flex flex-col justify-between backdrop-blur-xl ${
                    selectedShape === item.shape
                      ? isDark
                        ? 'border-amber-400 bg-white/10 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400'
                        : 'border-neutral-900 bg-neutral-50 shadow-lg ring-1 ring-neutral-900'
                      : isDark
                      ? 'border-white/10 hover:border-white/20 bg-white/[0.03] hover:bg-white/[0.06]'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <div>
                    <div className="text-3xl mb-3">{item.icon}</div>
                    <h4 className="font-bold text-base font-sans">{item.title}</h4>
                    <p className="mt-1.5 text-xs text-neutral-400 leading-relaxed">{item.desc}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/10 dark:border-white/10">
                    <div className="text-[11px] font-semibold text-amber-400 mb-1">Optical Rule:</div>
                    <div className="text-[11px] text-neutral-400 line-clamp-3">{item.rule}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 flex justify-end">
              <button
                id="btn-step1-next"
                onClick={() => setStep(2)}
                className={`flex items-center gap-2 px-6 py-3 rounded-full font-bold text-xs uppercase tracking-wider transition-all border ${
                  isDark
                    ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40 shadow-lg'
                    : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                }`}
              >
                <span>Continue to Style Vibe</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Style Vibe */}
        {step === 2 && (
          <div className="animate-fadeIn">
            <div className="mb-6">
              <h3 className="text-xl font-bold font-sans">Step 2: Choose Your Aesthetic & Daily Context</h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                How do you intend to wear your MGW eyewear?
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {STYLE_VIBES.map((vibe) => (
                <div
                  key={vibe.id}
                  id={`vibe-${vibe.id.toLowerCase().replace(/\s+/g, '-')}`}
                  onClick={() => setSelectedVibe(vibe.id)}
                  className={`p-6 rounded-2xl border cursor-pointer transition-all duration-300 flex flex-col justify-between backdrop-blur-xl ${
                    selectedVibe === vibe.id
                      ? isDark
                        ? 'border-amber-400 bg-white/10 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400'
                        : 'border-neutral-900 bg-neutral-50 shadow-lg ring-1 ring-neutral-900'
                      : isDark
                      ? 'border-white/10 hover:border-white/20 bg-white/[0.03] hover:bg-white/[0.06]'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <div>
                    <div className="text-3xl mb-3">{vibe.icon}</div>
                    <h4 className="font-bold text-base font-sans">{vibe.title}</h4>
                    <p className="mt-2 text-xs text-neutral-400 leading-relaxed">{vibe.subtitle}</p>
                  </div>

                  <div className="mt-4 pt-3 flex items-center justify-between text-xs">
                    <span className="text-neutral-500 font-mono">Selected</span>
                    {selectedVibe === vibe.id && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 flex justify-between">
              <button
                onClick={() => setStep(1)}
                className="px-5 py-3 rounded-full text-xs font-semibold text-neutral-400 hover:text-white"
              >
                ← Back
              </button>
              <button
                id="btn-step2-next"
                onClick={() => setStep(3)}
                className={`flex items-center gap-2 px-6 py-3 rounded-full font-bold text-xs uppercase tracking-wider transition-all border ${
                  isDark
                    ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40 shadow-lg'
                    : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                }`}
              >
                <span>Continue to Color & Finish</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Color & Metal Finish Preference */}
        {step === 3 && (
          <div className="animate-fadeIn">
            <div className="mb-6">
              <h3 className="text-xl font-bold font-sans">Step 3: Preferred Frame Tone & Finish</h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                Filter by metallic finishes, classic tones, or subtle natural hues.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              {COLOR_PREFERENCES.map((c) => (
                <div
                  key={c.name}
                  id={`pref-color-${c.name.toLowerCase().replace(/\s+/g, '-')}`}
                  onClick={() => setSelectedColorPref(c.name)}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all duration-300 flex flex-col justify-between backdrop-blur-xl ${
                    selectedColorPref === c.name
                      ? isDark
                        ? 'border-amber-400 bg-white/10 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400'
                        : 'border-neutral-900 bg-neutral-50 shadow-lg ring-1 ring-neutral-900'
                      : isDark
                      ? 'border-white/10 hover:border-white/20 bg-white/[0.03] hover:bg-white/[0.06]'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <div>
                    <div
                      className="w-8 h-8 rounded-full border-2 border-neutral-600 shadow-md mb-3"
                      style={{ backgroundColor: c.hex }}
                    />
                    <h4 className="font-bold text-sm font-sans">{c.name}</h4>
                    <p className="mt-1 text-xs text-neutral-400">{c.desc}</p>
                  </div>

                  <div className="mt-4 pt-3 flex items-center justify-between text-xs">
                    <span className="text-[10px] font-mono text-neutral-500">{c.hex}</span>
                    {selectedColorPref === c.name && (
                      <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 flex justify-between">
              <button
                onClick={() => setStep(2)}
                className="px-5 py-3 rounded-full text-xs font-semibold text-neutral-400 hover:text-white"
              >
                ← Back
              </button>
              <button
                id="btn-step3-reveal"
                onClick={() => setStep(4)}
                className={`flex items-center gap-2 px-8 py-3.5 rounded-full font-bold text-xs uppercase tracking-wider transition-all shadow-xl border ${
                  isDark
                    ? 'bg-amber-400 text-black hover:bg-amber-300 border-amber-300'
                    : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>Calculate My Recommended Frames</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Results & High-Match Recommendations */}
        {step === 4 && (
          <div className="animate-fadeIn">
            {/* Recommendation Summary Banner */}
            <div
              className={`p-6 sm:p-8 rounded-2xl border mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6 backdrop-blur-xl ${
                isDark
                  ? 'bg-white/[0.04] border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)]'
                  : 'bg-white/70 border-white/60 shadow-xl'
              }`}
            >
              <div>
                <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider mb-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Optical Diagnostic Report</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold font-sans">
                  Best Optical Matches for your{' '}
                  <span className="text-amber-400 font-serif italic">{selectedShape} Face</span>
                </h3>
                <p
                  className={`mt-2 text-xs sm:text-sm max-w-2xl leading-relaxed ${
                    isDark ? 'text-neutral-300' : 'text-neutral-700'
                  }`}
                >
                  Based on your preference for <strong>{selectedVibe}</strong> and{' '}
                  <strong>{selectedColorPref}</strong>, we have calculated proportional balance scores.
                  Our algorithms ensure brow line alignment and bridge comfort without pinching.
                </p>
              </div>

              <div className="flex items-center gap-3 self-start md:self-auto">
                <button
                  onClick={() => setStep(1)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold border transition-all backdrop-blur-xl ${
                    isDark
                      ? 'bg-white/5 border-white/15 text-neutral-300 hover:text-white hover:bg-white/10'
                      : 'bg-white border-neutral-300 text-neutral-700 hover:bg-neutral-100'
                  }`}
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restart Quiz</span>
                </button>
              </div>
            </div>

            {/* Recommended Products Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {matchingProducts.slice(0, 3).map(({ product, score }, idx) => (
                <div
                  key={product.id}
                  id={`match-product-${product.id}`}
                  className={`rounded-2xl border p-6 flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] backdrop-blur-xl ${
                    idx === 0
                      ? isDark
                        ? 'bg-violet-950/20 border-violet-500/40 shadow-2xl ring-1 ring-violet-500/30'
                        : 'bg-violet-50/50 border-violet-300 shadow-xl ring-1 ring-violet-400'
                      : isDark
                      ? 'bg-white/[0.03] border-white/10 shadow-lg'
                      : 'bg-white/80 border-white/60 shadow-md'
                  }`}
                >
                  <div>
                    {/* Match Score Badge */}
                    <div className="flex items-center justify-between mb-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold font-mono tracking-wider backdrop-blur-md ${
                          idx === 0
                            ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                            : isDark
                            ? 'bg-white/10 text-neutral-200 border border-white/10'
                            : 'bg-neutral-100 text-neutral-800'
                        }`}
                      >
                        {score}% Optical Match
                      </span>
                      {idx === 0 && (
                        <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                          ★ Top Selection
                        </span>
                      )}
                    </div>

                    {/* Image */}
                    <div className="aspect-[4/3] rounded-xl overflow-hidden bg-black/10 mb-4 p-3 flex items-center justify-center">
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="w-full h-full object-contain hover:scale-110 transition-transform duration-500"
                      />
                    </div>

                    <div className="text-xs font-mono text-neutral-400 uppercase">
                      {product.category} • {product.material}
                    </div>
                    <h4 className="font-bold text-lg mt-0.5">{product.name}</h4>
                    <p className="text-xs text-neutral-400 mt-1 line-clamp-2">{product.tagline}</p>

                    {/* Why this matches */}
                    <div
                      className={`mt-4 p-3 rounded-lg text-xs leading-relaxed border backdrop-blur-md ${
                        isDark
                          ? 'bg-white/[0.03] border-white/10 text-neutral-300'
                          : 'bg-neutral-50 border-neutral-200 text-neutral-700'
                      }`}
                    >
                      <span className="font-bold text-amber-400">Why it fits: </span>
                      {selectedShape === 'Square'
                        ? 'Curved edges and aviator bridge contrast with square jawlines to soften angular facial width.'
                        : selectedShape === 'Round'
                        ? 'Crisp geometric contours add structure and sharpen cheekbone definition.'
                        : 'Balanced bridge geometry matches your proportions with zero facial overhang.'}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-6 pt-4 border-t border-white/10 dark:border-white/10 flex items-center justify-between gap-2">
                    <span className="text-xl font-extrabold font-sans">${product.price}</span>

                    <div className="flex items-center gap-2">
                      <button
                        id={`btn-match-tryon-${product.id}`}
                        onClick={() => onOpenTryOn(product)}
                        className={`p-2.5 rounded-xl border backdrop-blur-xl transition-colors ${
                          isDark
                            ? 'border-white/15 hover:border-white/30 text-neutral-300 hover:bg-white/10'
                            : 'border-neutral-300 hover:border-neutral-400 text-neutral-700'
                        }`}
                        title="Virtual Try-On"
                      >
                        <Eye className="w-4 h-4 text-violet-400" />
                      </button>

                      <button
                        id={`btn-match-customize-${product.id}`}
                        onClick={() => onOpenCustomizer(product)}
                        className={`px-4 py-2 rounded-xl text-xs font-bold tracking-wide transition-all border ${
                          isDark
                            ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40 shadow-sm'
                            : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                        }`}
                      >
                        Customize Pair
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
