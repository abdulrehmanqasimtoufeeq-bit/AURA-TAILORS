import React, { useState } from 'react';
import { ThemeMode } from '../types';
import {
  ShieldCheck,
  Truck,
  RotateCcw,
  Sparkles,
  ArrowRight,
  Check,
  Mail,
  Film
} from 'lucide-react';

interface FooterProps {
  theme: ThemeMode;
  onOpenPromptModal: () => void;
  onOpenFaceFinder: () => void;
  onOpenVirtualTryOn: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  theme,
  onOpenPromptModal,
  onOpenFaceFinder,
  onOpenVirtualTryOn
}) => {
  const isDark = theme === 'dark';
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -70;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  return (
    <footer
      id="main-footer"
      className={`relative pt-16 pb-12 border-t z-10 backdrop-blur-2xl transition-colors ${
        isDark
          ? 'bg-[#0a0a0f]/85 border-white/10 text-neutral-400'
          : 'bg-white/80 border-neutral-200 text-neutral-600'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Assurance Banner */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pb-12 border-b border-white/10 dark:border-white/10">
          <div className="flex items-center gap-3.5 p-4 rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-xl">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-sm text-neutral-200 dark:text-neutral-100 font-sans">
                Lifetime Mechanical Guarantee
              </div>
              <div className="text-xs text-neutral-400 mt-0.5">
                Every Japanese titanium hinge and solder joint is covered for life.
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-4 rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-xl">
            <div className="w-10 h-10 rounded-xl bg-violet-500/10 text-violet-400 border border-violet-500/30 flex items-center justify-center shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-sm text-neutral-200 dark:text-neutral-100 font-sans">
                30-Day Risk-Free Home Trial
              </div>
              <div className="text-xs text-neutral-400 mt-0.5">
                Complimentary return shipping and full optical refunds.
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-4 rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-xl">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-sm text-neutral-200 dark:text-neutral-100 font-sans">
                Expedited Worldwide Delivery
              </div>
              <div className="text-xs text-neutral-400 mt-0.5">
                DHL Express Air courier with real-time tracking in 2-3 business days.
              </div>
            </div>
          </div>
        </div>

        {/* Middle Navigation & Newsletter Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 py-12 border-b border-white/10 dark:border-white/10">
          {/* Brand Info (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center font-extrabold text-sm border ${
                  isDark ? 'bg-white text-black border-white' : 'bg-black text-white border-black'
                }`}
              >
                MGW
              </div>
              <span className="font-extrabold text-xl tracking-tight font-sans text-neutral-100 dark:text-white">
                MGW • Men’s Glasses Wear
              </span>
            </div>
            <p className="text-xs leading-relaxed max-w-sm text-neutral-400">
              Engineered precision eyewear designed exclusively for masculine face architecture.
              Japanese Beta-Titanium and hand-polished Mazzucchelli Italian acetate crafted without compromise.
            </p>

            <button
              id="btn-footer-video-prompts"
              onClick={onOpenPromptModal}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-mono bg-violet-500/10 text-violet-300 border border-violet-500/30 hover:bg-violet-500/20 backdrop-blur-xl transition-colors"
            >
              <Film className="w-3.5 h-3.5" />
              <span>AI Video Background Prompts</span>
            </button>
          </div>

          {/* Nav Column 1 */}
          <div className="space-y-3 text-xs">
            <div className="font-bold uppercase tracking-wider text-neutral-200 dark:text-neutral-100 font-mono">
              Silhouettes
            </div>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => scrollToSection('gallery-section')}
                  className="hover:text-white transition-colors"
                >
                  Aviator Aerospace Series
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('gallery-section')}
                  className="hover:text-white transition-colors"
                >
                  Wayfarer Italian Acetate
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('gallery-section')}
                  className="hover:text-white transition-colors"
                >
                  Panthos Intellectual Round
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('gallery-section')}
                  className="hover:text-white transition-colors"
                >
                  Vanguard Square Precision
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('gallery-section')}
                  className="hover:text-white transition-colors"
                >
                  Strata 9.4g Rimless
                </button>
              </li>
            </ul>
          </div>

          {/* Nav Column 2 */}
          <div className="space-y-3 text-xs">
            <div className="font-bold uppercase tracking-wider text-neutral-200 dark:text-neutral-100 font-mono">
              Client Tools
            </div>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={onOpenVirtualTryOn}
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <span>Virtual 3D Try-On</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-violet-600 text-white font-mono">Live</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('customizer-section')}
                  className="hover:text-white transition-colors"
                >
                  300% Detail Inspector
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenFaceFinder}
                  className="hover:text-white transition-colors"
                >
                  3-Step Face Shape Finder
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('reviews-section')}
                  className="hover:text-white transition-colors"
                >
                  Verified Buyer Reviews
                </button>
              </li>
              <li>
                <a href="#hero" className="hover:text-white transition-colors">
                  Lifetime Warranty Claim
                </a>
              </li>
            </ul>
          </div>

          {/* Newsletter Column */}
          <div className="space-y-3 text-xs">
            <div className="font-bold uppercase tracking-wider text-neutral-200 dark:text-neutral-100 font-mono">
              The Gentleman’s Dispatch
            </div>
            <p className="text-[11px] leading-relaxed text-neutral-400">
              Receive limited-run bespoke release notices and an instant 15% discount code.
            </p>

            {subscribed ? (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs backdrop-blur-xl">
                ✓ Welcome to MGW Society. Use code <strong>MGW15</strong> at checkout.
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="gentleman@domain.com"
                    className={`w-full px-3.5 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-400 backdrop-blur-xl ${
                      isDark
                        ? 'bg-white/[0.04] border-white/15 text-white placeholder-neutral-500'
                        : 'bg-white border-neutral-300 text-neutral-900'
                    }`}
                  />
                  <Mail className="w-3.5 h-3.5 absolute right-3 top-2.5 text-neutral-500" />
                </div>
                <button
                  type="submit"
                  className={`w-full py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all border ${
                    isDark
                      ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40 shadow-sm'
                      : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                  }`}
                >
                  Join & Claim 15% Off
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Bottom Legal & Copyright Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-neutral-500">
          <div>
            © {new Date().getFullYear()} MGW (Men’s Glasses Wear) Inc. Engineered with Precision.
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:underline cursor-pointer">Privacy & GDPR</span>
            <span className="hover:underline cursor-pointer">Terms of Service</span>
            <span className="hover:underline cursor-pointer">Optical Prescription Policy</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
