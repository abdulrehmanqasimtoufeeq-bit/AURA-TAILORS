import React from 'react';
import { Product, ThemeMode, FrameColor } from '../types';
import { X, Heart, ShoppingBag, ArrowRight, Trash2 } from 'lucide-react';

interface WishlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistIds: string[];
  products: Product[];
  onRemoveFromWishlist: (productId: string) => void;
  onAddToCart: (product: Product, color: FrameColor) => void;
  onOpenCustomizer: (product: Product) => void;
  theme: ThemeMode;
}

export const WishlistModal: React.FC<WishlistModalProps> = ({
  isOpen,
  onClose,
  wishlistIds,
  products,
  onRemoveFromWishlist,
  onAddToCart,
  onOpenCustomizer,
  theme
}) => {
  if (!isOpen) return null;
  const isDark = theme === 'dark';

  const wishlistedProducts = products.filter((p) => wishlistIds.includes(p.id));

  return (
    <div
      id="wishlist-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="wishlist-modal-card"
        className={`relative w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-2xl border p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.8)] backdrop-blur-2xl transition-all ${
          isDark ? 'bg-[#0f0f15]/90 border-white/15 text-white' : 'bg-white/90 border-white/60 text-neutral-900'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-white/10 dark:border-white/10">
          <div className="flex items-center gap-2.5">
            <Heart className="w-5 h-5 text-rose-500 fill-current" />
            <h3 className="font-bold text-lg font-sans">Saved Wishlist Items</h3>
            <span className="text-xs font-mono text-neutral-400">
              ({wishlistedProducts.length})
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 border border-transparent hover:border-white/10 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-6 space-y-4">
          {wishlistedProducts.length === 0 ? (
            <div className="text-center py-12 text-neutral-500">
              <Heart className="w-10 h-10 mx-auto stroke-1 mb-2 opacity-40" />
              <p className="text-sm font-medium">No saved frames yet.</p>
              <p className="text-xs text-neutral-400 mt-1">
                Click the heart icon on any frame card to save for later.
              </p>
            </div>
          ) : (
            wishlistedProducts.map((p) => (
              <div
                key={p.id}
                className={`p-4 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-xl transition-all ${
                  isDark ? 'bg-white/[0.03] border-white/10' : 'bg-white/80 border-neutral-200'
                }`}
              >
                <div className="flex items-center gap-4 w-full sm:w-auto">
                  <img
                    src={p.imageUrl}
                    alt={p.name}
                    className="w-16 h-12 object-contain bg-black/20 rounded-lg p-1 border border-white/10"
                  />
                  <div>
                    <h4 className="font-bold text-sm">{p.name}</h4>
                    <div className="text-xs text-neutral-400 font-mono">
                      {p.category} • {p.material} • ${p.price}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    onClick={() => {
                      onAddToCart(p, p.colors[0]);
                      onRemoveFromWishlist(p.id);
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all border ${
                      isDark
                        ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40 shadow-sm'
                        : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                    }`}
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Move to Bag</span>
                  </button>

                  <button
                    onClick={() => onRemoveFromWishlist(p.id)}
                    className="p-2 rounded-xl text-neutral-400 hover:text-rose-400 hover:bg-white/10 transition-colors"
                    title="Remove from wishlist"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
