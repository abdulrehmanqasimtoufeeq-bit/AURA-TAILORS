import React, { useState } from 'react';
import { X, Copy, Check, Sparkles, Video, Film, Wand2 } from 'lucide-react';
import { ThemeMode } from '../types';

interface VideoPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
}

export const VideoPromptModal: React.FC<VideoPromptModalProps> = ({
  isOpen,
  onClose,
  theme
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const isDark = theme === 'dark';

  const copyToClipboard = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2200);
  };

  const PROMPTS = [
    {
      id: 'opt-1',
      title: 'Option 1: Modern & Abstract (Swirling Violet Tunnel)',
      tag: '60fps Seamless Loop',
      tools: ['Runway Gen-3', 'Pika 1.5', 'Sora', 'Luma Dream Machine'],
      prompt:
        'A seamless 4K looping background video of glowing neon violet and metallic metallic-grey curved lines swirling smoothly toward a dark center tunnel. Ultra-high definition, dark mode aesthetic, elegant motion graphics, minimalist luxury atmosphere, smooth 60fps.'
    },
    {
      id: 'opt-2',
      title: 'Option 2: Luxury Eyewear Showcase (Studio Space)',
      tag: 'Photorealistic 8K Render',
      tools: ['Runway Gen-3', 'Midjourney + Kling', 'Sora', 'Hunyuan Video'],
      prompt:
        'A seamless 4K looping background video showing high-end men’s eyewear floating slowly in a luxury studio space. Soft warm beige and dark slate background, subtle warm studio lighting, slow cinematic zoom-in, photorealistic 8K render, clean luxury aesthetic.'
    },
    {
      id: 'opt-3',
      title: 'Option 3: Macro Titanium Hinge & Bevel Zoom',
      tag: 'Macro Industrial Luxury',
      tools: ['Runway Gen-3 Alpha', 'Kling AI 1.5', 'Sora'],
      prompt:
        'Extreme macro cinematic 4K video of a precision-engineered Japanese titanium eyeglasses hinge opening and closing smoothly. Polished gunmetal finish, subtle light reflection running along the brushed metal arm, shallow depth of field, 24fps film grain.'
    }
  ];

  return (
    <div
      id="video-prompt-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl transition-all animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="video-prompt-modal-card"
        className={`relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border p-6 md:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.8)] backdrop-blur-2xl transition-all ${
          isDark
            ? 'bg-[#0f0f15]/90 border-white/15 text-neutral-100'
            : 'bg-white/90 border-white/60 text-neutral-900'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-5 border-b border-white/10 dark:border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/30 flex items-center justify-center text-violet-400 backdrop-blur-xl">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg tracking-tight font-sans">
                AI Video Background Prompts
              </h3>
              <p className="text-xs text-neutral-400">
                Tailored prompts for Pika, Runway Gen-3, Sora & Midjourney Video
              </p>
            </div>
          </div>
          <button
            id="btn-close-prompt-modal"
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 border border-transparent hover:border-white/10 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Prompt List */}
        <div className="mt-6 space-y-5">
          {PROMPTS.map((p) => {
            const isCopied = copiedKey === p.id;
            return (
              <div
                key={p.id}
                id={`prompt-card-${p.id}`}
                className={`p-5 rounded-xl border transition-all backdrop-blur-xl ${
                  isDark
                    ? 'bg-white/[0.03] border-white/10 hover:border-white/20'
                    : 'bg-white/80 border-white/60 hover:border-neutral-300'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <Film className="w-4 h-4 text-violet-400" />
                    <span className="font-semibold text-sm">{p.title}</span>
                  </div>
                  <span className="text-[11px] px-2.5 py-0.5 rounded-full font-mono font-medium bg-violet-500/10 text-violet-300 border border-violet-500/20 backdrop-blur-xl">
                    {p.tag}
                  </span>
                </div>

                <div
                  className={`p-3.5 rounded-xl my-3 font-mono text-xs leading-relaxed select-all backdrop-blur-xl ${
                    isDark
                      ? 'bg-black/40 text-neutral-200 border border-white/10'
                      : 'bg-neutral-100 text-neutral-800 border border-neutral-200'
                  }`}
                >
                  "{p.prompt}"
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs">
                  <div className="flex items-center gap-1.5 text-neutral-400">
                    <span className="text-[11px] font-medium font-mono">Tools:</span>
                    {p.tools.map((t, idx) => (
                      <span
                        key={t}
                        className={`text-[10px] px-2 py-0.5 rounded-lg border ${
                          isDark ? 'bg-white/[0.04] text-neutral-300 border-white/10' : 'bg-neutral-200 text-neutral-700 border-neutral-300'
                        }`}
                      >
                        {t}
                      </span>
                    ))}
                  </div>

                  <button
                    id={`btn-copy-prompt-${p.id}`}
                    onClick={() => copyToClipboard(p.id, p.prompt)}
                    className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
                      isCopied
                        ? 'bg-emerald-600 text-white border-emerald-500 shadow-sm'
                        : isDark
                        ? 'bg-white/10 hover:bg-white/20 text-white border-white/15 shadow-sm'
                        : 'bg-neutral-900 hover:bg-neutral-800 text-white border-black'
                    }`}
                  >
                    {isCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Copied to Clipboard!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Prompt</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer tip */}
        <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-neutral-400">
          <span>Tip: Set loop mode to true for seamless hero transitions.</span>
          <button
            onClick={onClose}
            className="font-medium hover:underline text-neutral-300 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
