import React, { useState, useRef, useEffect } from 'react';
import { Product, ThemeMode, FrameColor } from '../types';
import {
  X,
  Camera,
  RotateCcw,
  Sliders,
  Sparkles,
  ShoppingBag,
  Eye,
  Check,
  ZoomIn,
  Move
} from 'lucide-react';

interface VirtualTryOnModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  activeProduct: Product;
  onSelectProduct: (product: Product) => void;
  theme: ThemeMode;
  onAddToCart: (product: Product, color: FrameColor) => void;
  onOpenCustomizer: (product: Product) => void;
}

export const VirtualTryOnModal: React.FC<VirtualTryOnModalProps> = ({
  isOpen,
  onClose,
  products,
  activeProduct,
  onSelectProduct,
  theme,
  onAddToCart,
  onOpenCustomizer
}) => {
  const isDark = theme === 'dark';

  const [useCamera, setUseCamera] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [selectedModelIdx, setSelectedModelIdx] = useState(0);
  const [selectedColorId, setSelectedColorId] = useState(activeProduct.colors[0].id);

  // Position & scale adjustments
  const [overlayScale, setOverlayScale] = useState(1.0);
  const [overlayPosY, setOverlayPosY] = useState(0);
  const [overlayTilt, setOverlayTilt] = useState(0);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const MODEL_FACES = [
    {
      name: 'Alexander (Square Jawline)',
      shape: 'Square',
      imgUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=800&q=85'
    },
    {
      name: 'Julian (Oval Architecture)',
      shape: 'Oval',
      imgUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=85'
    },
    {
      name: 'Damian (Heart / Angular)',
      shape: 'Heart',
      imgUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=800&q=85'
    },
    {
      name: 'Marcus (Diamond / High Cheekbones)',
      shape: 'Diamond',
      imgUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=800&q=85'
    }
  ];

  // Stop camera on unmount or close
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  const toggleCamera = async () => {
    if (useCamera) {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
      setUseCamera(false);
      return;
    }

    try {
      setCameraError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setUseCamera(true);
    } catch (err: any) {
      setCameraError('Camera access unavailable. Using high-definition studio face models.');
      setUseCamera(false);
    }
  };

  if (!isOpen) return null;

  const currentColor =
    activeProduct.colors.find((c) => c.id === selectedColorId) || activeProduct.colors[0];

  return (
    <div
      id="tryon-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="tryon-modal-card"
        className={`relative w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-2xl border p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.7)] backdrop-blur-2xl transition-all ${
          isDark ? 'bg-[#0f0f15]/90 border-white/15 text-white' : 'bg-white/90 border-white/60 text-neutral-900'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 dark:border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/30 flex items-center justify-center text-violet-400 backdrop-blur-xl">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg tracking-tight font-sans">
                Virtual 3D Try-On & Fit Simulator
              </h3>
              <p className="text-xs text-neutral-400 font-mono">
                Preview scale, bridge alignment, and frame proportions in real time
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 border border-transparent hover:border-white/10 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Simulator Workspace (2 Columns) */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Visual Viewport with Glasses Overlay (7 Cols) */}
          <div className="lg:col-span-7 flex flex-col gap-3">
            <div
              className={`relative aspect-[4/3] rounded-2xl overflow-hidden border flex items-center justify-center backdrop-blur-xl ${
                isDark ? 'bg-black/60 border-white/15' : 'bg-neutral-200/80 border-white/60'
              }`}
            >
              {/* Background Video or Model Photo */}
              {useCamera ? (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover transform -scale-x-100"
                />
              ) : (
                <img
                  src={MODEL_FACES[selectedModelIdx].imgUrl}
                  alt={MODEL_FACES[selectedModelIdx].name}
                  className="w-full h-full object-cover"
                />
              )}

              {/* Glasses Overlay Asset */}
              <div
                className="absolute z-20 pointer-events-none transition-transform duration-75 flex items-center justify-center w-[58%] select-none"
                style={{
                  top: `calc(44% + ${overlayPosY}px)`,
                  transform: `scale(${overlayScale}) rotate(${overlayTilt}deg)`
                }}
              >
                <img
                  src={activeProduct.imageUrl}
                  alt="Glasses Overlay"
                  className="w-full h-auto drop-shadow-[0_15px_25px_rgba(0,0,0,0.8)] filter brightness-95 contrast-105"
                />
                {/* Subtle Lens Reflection Glass Glare */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none rounded-lg" />
              </div>

              {/* Viewport Overlay Controls & Badges */}
              <div className="absolute top-3 left-3 z-30 flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-black/60 text-white backdrop-blur-xl border border-white/15">
                  {useCamera ? '● Live Camera' : MODEL_FACES[selectedModelIdx].shape + ' Face'}
                </span>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-mono bg-violet-600/80 text-white backdrop-blur-md border border-violet-400/30">
                  {activeProduct.name.split(' ')[0]}
                </span>
              </div>

              {/* Camera Switcher Button inside Viewport */}
              <div className="absolute bottom-3 right-3 z-30">
                <button
                  id="btn-toggle-tryon-camera"
                  onClick={toggleCamera}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold backdrop-blur-xl border transition-all ${
                    useCamera
                      ? 'bg-rose-600 text-white border-rose-500 shadow-md'
                      : 'bg-black/60 text-neutral-200 hover:text-white border-white/20 hover:border-white/40'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{useCamera ? 'Stop Camera' : 'Use My Webcam'}</span>
                </button>
              </div>
            </div>

            {/* Micro Calibration Sliders */}
            <div
              className={`p-4 rounded-2xl border text-xs backdrop-blur-xl ${
                isDark ? 'bg-white/[0.03] border-white/10 text-neutral-300' : 'bg-white/80 border-white/60 text-neutral-800'
              }`}
            >
              <div className="flex items-center justify-between mb-2.5">
                <span className="font-bold flex items-center gap-1 text-[11px] uppercase tracking-wider text-amber-400">
                  <Move className="w-3 h-3" /> Fit Calibration:
                </span>
                <button
                  onClick={() => {
                    setOverlayScale(1.0);
                    setOverlayPosY(0);
                    setOverlayTilt(0);
                  }}
                  className="text-[10px] text-neutral-400 hover:text-white flex items-center gap-1 transition-colors"
                >
                  <RotateCcw className="w-2.5 h-2.5" /> Reset
                </button>
              </div>

              <div className="grid grid-cols-3 gap-3 text-[11px]">
                <div>
                  <div className="flex justify-between text-neutral-400 mb-1">
                    <span>Scale</span>
                    <span className="font-mono text-amber-400">{overlayScale.toFixed(2)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.75"
                    max="1.35"
                    step="0.02"
                    value={overlayScale}
                    onChange={(e) => setOverlayScale(parseFloat(e.target.value))}
                    className="w-full accent-amber-400 h-1 bg-white/20 rounded-lg cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-neutral-400 mb-1">
                    <span>Position</span>
                    <span className="font-mono text-amber-400">{overlayPosY}px</span>
                  </div>
                  <input
                    type="range"
                    min="-40"
                    max="40"
                    step="2"
                    value={overlayPosY}
                    onChange={(e) => setOverlayPosY(parseInt(e.target.value))}
                    className="w-full accent-amber-400 h-1 bg-white/20 rounded-lg cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-neutral-400 mb-1">
                    <span>Tilt Angle</span>
                    <span className="font-mono text-amber-400">{overlayTilt}°</span>
                  </div>
                  <input
                    type="range"
                    min="-15"
                    max="15"
                    step="1"
                    value={overlayTilt}
                    onChange={(e) => setOverlayTilt(parseInt(e.target.value))}
                    className="w-full accent-amber-400 h-1 bg-white/20 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {cameraError && (
              <p className="text-[11px] text-amber-400 font-mono">{cameraError}</p>
            )}
          </div>

          {/* Right Column: Model Switcher & Frame Selection (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {/* Model Presets */}
            {!useCamera && (
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2 font-mono">
                  Select Face Structure Preset
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {MODEL_FACES.map((m, idx) => (
                    <button
                      key={m.name}
                      onClick={() => setSelectedModelIdx(idx)}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 text-left transition-all backdrop-blur-xl ${
                        selectedModelIdx === idx
                          ? isDark
                            ? 'border-amber-400/80 bg-amber-400/10 text-white shadow-sm'
                            : 'border-neutral-900 bg-neutral-100 shadow-sm'
                          : isDark
                          ? 'border-white/10 bg-white/[0.02] text-neutral-400 hover:border-white/20'
                          : 'border-white/60 bg-white/60 text-neutral-700'
                      }`}
                    >
                      <img
                        src={m.imgUrl}
                        alt={m.name}
                        className="w-7 h-7 rounded-full object-cover border border-white/20"
                      />
                      <div className="truncate">
                        <div className="text-xs font-bold truncate">{m.shape}</div>
                        <div className="text-[10px] text-neutral-400 truncate">{m.name.split(' ')[0]}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Switch Glasses Frame */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2 font-mono">
                Switch Eyewear Frame
              </label>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {products.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      onSelectProduct(p);
                      setSelectedColorId(p.colors[0].id);
                    }}
                    className={`w-full p-2.5 rounded-xl border flex items-center justify-between text-left transition-all backdrop-blur-xl ${
                      activeProduct.id === p.id
                        ? isDark
                          ? 'border-violet-500/80 bg-violet-500/15 text-white shadow-sm'
                          : 'border-violet-600 bg-violet-50'
                        : isDark
                        ? 'border-white/10 hover:border-white/20 bg-white/[0.02] text-neutral-300'
                        : 'border-white/60 hover:border-neutral-300 bg-white/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={p.imageUrl}
                        alt={p.name}
                        className="w-10 h-8 object-contain"
                      />
                      <div>
                        <div className="text-xs font-bold">{p.name}</div>
                        <div className="text-[10px] text-neutral-400">
                          {p.category} • {p.material}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs font-bold font-sans">${p.price}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Finish Color Swatches */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2 font-mono">
                Frame Finish Color
              </label>
              <div className="flex items-center gap-2">
                {activeProduct.colors.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedColorId(c.id)}
                    className={`w-7 h-7 rounded-full border-2 transition-all ${
                      currentColor.id === c.id
                        ? 'ring-2 ring-amber-400 scale-110 border-white'
                        : 'border-white/30 hover:scale-105'
                    }`}
                    style={{ backgroundColor: c.hex }}
                    title={c.name}
                  />
                ))}
                <span className="text-xs text-neutral-300 font-medium ml-2">
                  {currentColor.name}
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-4 pt-4 border-t border-white/10 dark:border-white/10 flex flex-col gap-2.5">
              <button
                id="btn-tryon-add-to-cart"
                onClick={() => {
                  onAddToCart(activeProduct, currentColor);
                  onClose();
                }}
                className={`w-full py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all border ${
                  isDark
                    ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40 shadow-lg'
                    : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add Selected Pair to Bag (${activeProduct.price})</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenCustomizer(activeProduct);
                }}
                className="w-full py-2.5 rounded-xl text-xs font-semibold text-center border border-white/15 hover:border-white/30 bg-white/[0.03] backdrop-blur-xl text-neutral-300 hover:text-white transition-all"
              >
                Open in 300% Customizer Studio
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
