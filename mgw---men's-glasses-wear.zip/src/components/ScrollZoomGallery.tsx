import React, { useState, useEffect, useRef } from 'react';
import {
  Product,
  FrameCategory,
  ThemeMode,
  FrameColor
} from '../types';
import {
  Search,
  ZoomIn,
  SlidersHorizontal,
  Eye,
  Heart,
  ShoppingBag,
  ArrowUpRight,
  Shield,
  Sparkles,
  Layers,
  Check
} from 'lucide-react';

interface ScrollZoomGalleryProps {
  products: Product[];
  theme: ThemeMode;
  onSelectProduct: (product: Product, initialColorId?: string) => void;
  onOpenCustomizerForProduct: (product: Product, colorId?: string) => void;
  onOpenTryOnForProduct: (product: Product) => void;
  onAddToCart: (product: Product, color: FrameColor) => void;
  wishlistIds: string[];
  onToggleWishlist: (productId: string) => void;
}

export const ScrollZoomGallery: React.FC<ScrollZoomGalleryProps> = ({
  products,
  theme,
  onSelectProduct,
  onOpenCustomizerForProduct,
  onOpenTryOnForProduct,
  onAddToCart,
  wishlistIds,
  onToggleWishlist
}) => {
  const [activeCategory, setActiveCategory] = useState<FrameCategory>('All');
  const [selectedColorMap, setSelectedColorMap] = useState<Record<string, string>>({});
  const [scrollProgress, setScrollProgress] = useState(1.0); // 1.0 to 1.6x zoom scale
  const [hoveredCardId, setHoveredCardId] = useState<string | null>(null);
  const [activeTabAngle, setActiveTabAngle] = useState<'front' | 'angle' | 'hinge'>('front');
  const sectionRef = useRef<HTMLDivElement | null>(null);

  const isDark = theme === 'dark';

  // Zoom-on-scroll dynamic calculation
  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current) return;
      const rect = sectionRef.current.getBoundingClientRect();
      const windowHeight = window.innerHeight;

      if (rect.top < windowHeight && rect.bottom > 0) {
        // Calculate normalized progress within the section
        const totalHeight = rect.height;
        const visibleTop = Math.max(0, windowHeight - rect.top);
        const ratio = Math.min(Math.max(visibleTop / (totalHeight + windowHeight), 0), 1);
        // Smooth scale range from 1.0x to 1.35x zoom on scroll
        const calculatedScale = 1.0 + ratio * 0.35;
        setScrollProgress(calculatedScale);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const categories: FrameCategory[] = ['All', 'Aviator', 'Wayfarer', 'Round', 'Square', 'Rimless'];

  const filteredProducts = products.filter((p) => {
    if (activeCategory === 'All') return true;
    return p.category === activeCategory;
  });

  const getSelectedColor = (product: Product): FrameColor => {
    const colorId = selectedColorMap[product.id] || product.colors[0].id;
    return product.colors.find((c) => c.id === colorId) || product.colors[0];
  };

  const handleColorSelect = (productId: string, colorId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedColorMap((prev) => ({ ...prev, [productId]: colorId }));
  };

  return (
    <section
      ref={sectionRef}
      id="gallery-section"
      className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10"
    >
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-10 border-b border-white/10 dark:border-white/10">
        <div>
          <div className="flex items-center gap-2.5 mb-2">
            <span className="w-2.5 h-2.5 rounded-full bg-violet-400 animate-pulse" />
            <span
              className={`text-xs font-mono font-bold uppercase tracking-widest ${
                isDark ? 'text-violet-400' : 'text-violet-700'
              }`}
            >
              Section 02 — Interactive Showcase
            </span>
          </div>

          <h2
            id="gallery-title"
            className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight font-sans"
          >
            Product Gallery{' '}
            <span className="font-serif italic font-normal text-amber-400">
              (Zoom-On-Scroll)
            </span>
          </h2>
          <p
            className={`mt-2 text-sm sm:text-base max-w-xl ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}
          >
            Scroll through the curated masterworks. Notice the automatic macro magnification
            revealing Japanese micro-filigree, hand-buffed acetate bevels, and titanium hinge assemblies.
          </p>
        </div>

        {/* Dynamic Zoom Indicator */}
        <div
          className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl border backdrop-blur-xl self-start md:self-auto shadow-lg ${
            isDark
              ? 'bg-white/[0.05] border-white/15 text-neutral-200'
              : 'bg-white/80 border-white/60 text-neutral-800 shadow-sm'
          }`}
        >
          <ZoomIn className="w-4 h-4 text-violet-400 animate-pulse" />
          <div className="flex flex-col text-xs font-mono">
            <span className="text-[10px] text-neutral-400 uppercase">Live Scroll Optical Zoom</span>
            <span className="font-bold text-sm text-violet-300">{(scrollProgress * 100).toFixed(0)}% Scale</span>
          </div>
          <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden ml-1">
            <div
              className="h-full bg-gradient-to-r from-violet-500 to-amber-400 rounded-full transition-all duration-150"
              style={{ width: `${Math.min(100, (scrollProgress - 1.0) / 0.35 * 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="mt-8 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-xl">
          {categories.map((cat) => (
            <button
              key={cat}
              id={`tab-category-${cat.toLowerCase()}`}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-xs sm:text-sm font-semibold tracking-wide transition-all ${
                activeCategory === cat
                  ? isDark
                    ? 'bg-white text-neutral-950 shadow-md font-bold'
                    : 'bg-neutral-950 text-white shadow-md font-bold'
                  : isDark
                  ? 'text-neutral-400 hover:text-white hover:bg-white/10'
                  : 'text-neutral-600 hover:text-neutral-900 hover:bg-black/5'
              }`}
            >
              {cat === 'All' ? 'All Masterpieces' : cat}
              {cat === 'Aviator' && ' ✈️'}
              {cat === 'Wayfarer' && ' 🕶️'}
              {cat === 'Round' && ' ⭕'}
              {cat === 'Square' && ' ⬛'}
              {cat === 'Rimless' && ' 🪶'}
            </button>
          ))}
        </div>

        {/* Macro Angle Inspector View Switcher */}
        <div
          className={`flex items-center gap-1 p-1 rounded-full border text-xs font-medium backdrop-blur-xl ${
            isDark ? 'bg-white/[0.04] border-white/10' : 'bg-white/80 border-white/60'
          }`}
        >
          <button
            onClick={() => setActiveTabAngle('front')}
            className={`px-3 py-1 rounded-full transition-all ${
              activeTabAngle === 'front'
                ? isDark
                  ? 'bg-violet-600 text-white font-bold shadow-xs'
                  : 'bg-neutral-900 text-white font-bold shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Front View
          </button>
          <button
            onClick={() => setActiveTabAngle('angle')}
            className={`px-3 py-1 rounded-full transition-all ${
              activeTabAngle === 'angle'
                ? isDark
                  ? 'bg-violet-600 text-white font-bold shadow-xs'
                : 'bg-neutral-900 text-white font-bold shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            45° Perspective
          </button>
          <button
            onClick={() => setActiveTabAngle('hinge')}
            className={`px-3 py-1 rounded-full transition-all ${
              activeTabAngle === 'hinge'
                ? isDark
                  ? 'bg-violet-600 text-white font-bold shadow-xs'
                  : 'bg-neutral-900 text-white font-bold shadow-xs'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Hinge Macro
          </button>
        </div>
      </div>

      {/* Product Grid with Zoom-On-Scroll Animations */}
      <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProducts.map((product) => {
          const selectedColor = getSelectedColor(product);
          const isWishlisted = wishlistIds.includes(product.id);
          const isHovered = hoveredCardId === product.id;

          // Choose image based on global angle tab or hover state
          let activeImage = product.imageUrl;
          if (activeTabAngle === 'angle') activeImage = product.angleImageUrl;
          if (activeTabAngle === 'hinge') activeImage = product.hingeImageUrl;
          if (isHovered && activeTabAngle === 'front') activeImage = product.angleImageUrl;

          return (
            <div
              key={product.id}
              id={`product-card-${product.id}`}
              onMouseEnter={() => setHoveredCardId(product.id)}
              onMouseLeave={() => setHoveredCardId(null)}
              onClick={() => onSelectProduct(product, selectedColor.id)}
              className={`group relative rounded-2xl border transition-all duration-500 overflow-hidden cursor-pointer flex flex-col justify-between backdrop-blur-xl ${
                isDark
                  ? 'bg-white/[0.03] border-white/10 hover:border-white/25 hover:bg-white/[0.06] hover:shadow-[0_20px_40px_rgba(0,0,0,0.6)]'
                  : 'bg-white/70 border-white/60 hover:border-white hover:bg-white/90 hover:shadow-xl'
              }`}
            >
              {/* Top Badges */}
              <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between pointer-events-none">
                <div className="flex items-center gap-1.5 pointer-events-auto">
                  {product.isBestSeller && (
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-amber-400 text-black shadow-md shadow-amber-400/20">
                      Best Seller
                    </span>
                  )}
                  {product.isNew && (
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-violet-600 text-white shadow-md shadow-violet-600/30">
                      New 2026
                    </span>
                  )}
                  <span
                    className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-medium backdrop-blur-xl border border-white/10 ${
                      isDark ? 'bg-black/40 text-neutral-300' : 'bg-white/80 text-neutral-700'
                    }`}
                  >
                    {product.dimensions.frameWeight}g
                  </span>
                </div>

                {/* Wishlist Button */}
                <button
                  id={`btn-wishlist-${product.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleWishlist(product.id);
                  }}
                  className={`p-2 rounded-full backdrop-blur-xl border border-white/15 pointer-events-auto transition-all ${
                    isWishlisted
                      ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30'
                      : isDark
                      ? 'bg-white/5 text-neutral-300 hover:text-white hover:bg-white/15 shadow-sm'
                      : 'bg-white/80 text-neutral-700 hover:text-neutral-900 hover:bg-white shadow-sm'
                  }`}
                  aria-label="Wishlist Toggle"
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Image Showcase with Zoom-On-Scroll Transformation */}
              <div className="relative w-full aspect-[4/3] overflow-hidden bg-black/20 dark:bg-black/40 flex items-center justify-center p-6 border-b border-white/5">
                <img
                  src={activeImage}
                  alt={product.name}
                  loading="lazy"
                  className="w-full h-full object-cover rounded-lg transition-transform duration-700 ease-out group-hover:scale-110"
                  style={{
                    transform: `scale(${isHovered ? 1.15 : scrollProgress})`
                  }}
                />

                {/* Subtle Lens Reflection Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

                {/* Quick Inspect Macro Pill on Hover */}
                <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-semibold bg-white/10 text-white backdrop-blur-2xl border border-white/20 shadow-lg pointer-events-auto">
                  <ZoomIn className="w-3.5 h-3.5 text-violet-400" />
                  <span>Inspect 300%</span>
                </div>
              </div>

              {/* Card Body & Specs */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  {/* Category & Series */}
                  <div className="flex items-center justify-between text-xs text-neutral-400 font-mono mb-1">
                    <span className="uppercase tracking-wider text-violet-400">{product.category} Silhouette</span>
                    <span>{product.series}</span>
                  </div>

                  {/* Product Name */}
                  <h3 className="text-xl font-bold font-sans tracking-tight leading-snug group-hover:text-amber-400 transition-colors">
                    {product.name}
                  </h3>

                  {/* Tagline */}
                  <p
                    className={`mt-1.5 text-xs line-clamp-2 leading-relaxed ${
                      isDark ? 'text-neutral-400' : 'text-neutral-600'
                    }`}
                  >
                    {product.tagline}
                  </p>

                  {/* Color Swatches (Matte Black, Gunmetal Grey, Soft Beige, Tortoiseshell) */}
                  <div className="mt-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-mono text-neutral-400">Finish:</span>
                      <div className="flex items-center gap-1.5">
                        {product.colors.map((c) => (
                          <button
                            key={c.id}
                            id={`color-${product.id}-${c.id}`}
                            onClick={(e) => handleColorSelect(product.id, c.id, e)}
                            className={`w-5 h-5 rounded-full border-2 transition-all ${
                              selectedColor.id === c.id
                                ? 'ring-2 ring-amber-400 scale-110 border-white'
                                : 'border-white/20 hover:scale-105'
                            }`}
                            style={{ backgroundColor: c.hex }}
                            title={c.name}
                          />
                        ))}
                      </div>
                    </div>

                    <span className="text-xs font-medium text-neutral-400 truncate max-w-[130px]">
                      {selectedColor.name}
                    </span>
                  </div>

                  {/* Dimensions Specification Pill */}
                  <div
                    className={`mt-3.5 px-3.5 py-1.5 rounded-xl text-[11px] font-mono flex items-center justify-between border backdrop-blur-xl ${
                      isDark
                        ? 'bg-white/[0.02] border-white/10 text-neutral-300'
                        : 'bg-white/60 border-white/60 text-neutral-700'
                    }`}
                  >
                    <span>Lens: {product.dimensions.lensWidth}mm</span>
                    <span>Bridge: {product.dimensions.bridgeWidth}mm</span>
                    <span>Temple: {product.dimensions.templeLength}mm</span>
                  </div>
                </div>

                {/* Price & Action Buttons */}
                <div className="mt-6 pt-4 border-t border-white/10 dark:border-white/10 flex items-center justify-between gap-3">
                  <div className="flex flex-col">
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-extrabold tracking-tight font-sans text-white">
                        ${product.price}
                      </span>
                      {product.originalPrice && (
                        <span className="text-xs line-through text-neutral-500">
                          ${product.originalPrice}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-emerald-400 font-medium">
                      ✓ Free Express Worldwide
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      id={`btn-tryon-${product.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenTryOnForProduct(product);
                      }}
                      className={`p-2.5 rounded-xl border backdrop-blur-xl transition-all ${
                        isDark
                          ? 'border-white/15 hover:border-violet-400/50 text-neutral-200 hover:text-white bg-white/[0.04] hover:bg-violet-600/20'
                          : 'border-neutral-300 hover:border-neutral-400 text-neutral-700 hover:text-neutral-900 bg-white'
                      }`}
                      title="Virtual Try-On"
                    >
                      <Eye className="w-4 h-4 text-violet-400" />
                    </button>

                    <button
                      id={`btn-customize-${product.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenCustomizerForProduct(product, selectedColor.id);
                      }}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold tracking-wide transition-all flex items-center gap-1.5 border ${
                        isDark
                          ? 'bg-white text-neutral-950 hover:bg-neutral-100 shadow-md border-white/40'
                          : 'bg-neutral-950 text-white hover:bg-neutral-800 shadow-md border-black'
                      }`}
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>Customize</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
