import React, { useState } from 'react';
import { Review, ThemeMode } from '../types';
import { REVIEWS_DATA, BRAND_STATS } from '../data/reviews';
import {
  Star,
  ShieldCheck,
  CheckCircle,
  ThumbsUp,
  MessageSquarePlus,
  Filter,
  Sparkles,
  User,
  X
} from 'lucide-react';

interface ReviewsSectionProps {
  theme: ThemeMode;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ theme }) => {
  const isDark = theme === 'dark';

  const [reviews, setReviews] = useState<Review[]>(REVIEWS_DATA);
  const [selectedRatingFilter, setSelectedRatingFilter] = useState<number | 'all'>('all');
  const [isWriteModalOpen, setIsWriteModalOpen] = useState(false);

  // New Review Form State
  const [newAuthor, setNewAuthor] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newModel, setNewModel] = useState('Aeronaut Titanium 01');
  const [newFit, setNewFit] = useState<'True to Size' | 'Runs Narrow' | 'Generous Fit'>('True to Size');

  const filteredReviews = reviews.filter((r) => {
    if (selectedRatingFilter === 'all') return true;
    return r.rating === selectedRatingFilter;
  });

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newContent.trim()) return;

    const newRev: Review = {
      id: `rev-${Date.now()}`,
      author: newAuthor,
      location: newLocation || 'Verified Buyer',
      rating: newRating,
      title: newTitle || 'Exceptional craftsmanship & comfort',
      content: newContent,
      date: 'Just now',
      verified: true,
      frameModel: newModel,
      frameColor: 'Matte Stealth Black',
      fitRating: newFit
    };

    setReviews([newRev, ...reviews]);
    setIsWriteModalOpen(false);
    // Reset form
    setNewAuthor('');
    setNewLocation('');
    setNewTitle('');
    setNewContent('');
  };

  return (
    <section
      id="reviews-section"
      className="relative py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10"
    >
      {/* Section Badge */}
      <div className="flex items-center gap-2.5 mb-2">
        <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
        <span
          className={`text-xs font-mono font-bold uppercase tracking-widest ${
            isDark ? 'text-amber-400' : 'text-amber-800'
          }`}
        >
          Section 05 — Verified Patron Testimonials
        </span>
      </div>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-white/10 dark:border-white/10">
        <div>
          <h2
            id="reviews-title"
            className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight font-sans"
          >
            Customer Reviews &{' '}
            <span className="font-serif italic font-normal text-amber-400">Fit Reports</span>
          </h2>
          <p
            className={`mt-2 text-sm sm:text-base max-w-2xl ${
              isDark ? 'text-neutral-400' : 'text-neutral-600'
            }`}
          >
            Read candid feedback from verified gentlemen worldwide regarding all-day comfort,
            Japanese titanium resilience, and the precision of our virtual try-on recommendations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            id="btn-write-review"
            onClick={() => setIsWriteModalOpen(true)}
            className={`flex items-center gap-2 px-5 py-3 rounded-full text-xs font-bold tracking-wide transition-all shadow-lg border ${
              isDark
                ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40'
                : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
            }`}
          >
            <MessageSquarePlus className="w-4 h-4" />
            <span>Write a Review</span>
          </button>
        </div>
      </div>

      {/* Brand Craft Stats Bar */}
      <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
        {BRAND_STATS.map((stat) => (
          <div
            key={stat.label}
            className={`p-5 rounded-2xl border flex flex-col justify-center text-center backdrop-blur-xl transition-all ${
              isDark ? 'bg-white/[0.03] border-white/10 shadow-lg' : 'bg-white/70 border-white/60 shadow-md'
            }`}
          >
            <div className="text-2xl sm:text-3xl font-extrabold font-sans text-amber-400">
              {stat.value}
            </div>
            <div className="text-xs text-neutral-400 mt-1 font-medium">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Rating Filters */}
      <div className="mt-8 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 p-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur-xl">
          <span className="text-xs font-mono text-neutral-400 uppercase pl-2">Filter:</span>
          {(['all', 5, 4] as const).map((r) => (
            <button
              key={r}
              onClick={() => setSelectedRatingFilter(r)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all ${
                selectedRatingFilter === r
                  ? isDark
                    ? 'bg-amber-400 text-black font-bold shadow-sm'
                    : 'bg-neutral-900 text-white font-bold shadow-sm'
                  : isDark
                  ? 'text-neutral-300 hover:text-white hover:bg-white/10'
                  : 'text-neutral-700 hover:text-neutral-900 hover:bg-black/5'
              }`}
            >
              {r === 'all' ? 'All Reviews' : `${r} Stars ★`}
            </button>
          ))}
        </div>

        <div className="text-xs font-mono text-neutral-400">
          Showing {filteredReviews.length} Verified Buyer Evaluations
        </div>
      </div>

      {/* Review Cards Grid */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredReviews.map((rev) => (
          <div
            key={rev.id}
            id={`review-card-${rev.id}`}
            className={`p-6 rounded-2xl border flex flex-col justify-between transition-all duration-300 hover:scale-[1.01] backdrop-blur-xl ${
              isDark
                ? 'bg-white/[0.03] border-white/10 hover:border-white/20 shadow-lg'
                : 'bg-white/75 border-white/60 hover:border-neutral-300 shadow-md'
            }`}
          >
            <div>
              {/* Star Rating & Verified Badge */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1 text-amber-400">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < rev.rating ? 'fill-current text-amber-400' : 'text-neutral-600'
                      }`}
                    />
                  ))}
                </div>

                {rev.verified && (
                  <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-400 font-mono">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Verified Buyer</span>
                  </span>
                )}
              </div>

              {/* Title */}
              <h3 className="font-bold text-base font-sans leading-snug">"{rev.title}"</h3>

              {/* Content */}
              <p
                className={`mt-2.5 text-xs sm:text-sm leading-relaxed ${
                  isDark ? 'text-neutral-300' : 'text-neutral-700'
                }`}
              >
                {rev.content}
              </p>

              {/* Fit & Model Badges */}
              <div className="mt-4 flex flex-wrap items-center gap-2">
                <span
                  className={`text-[10px] px-2.5 py-1 rounded font-mono ${
                    isDark ? 'bg-white/10 text-neutral-300' : 'bg-neutral-100 text-neutral-800'
                  }`}
                >
                  Model: {rev.frameModel}
                </span>
                <span className="text-[10px] px-2.5 py-1 rounded font-mono bg-violet-500/10 text-violet-400 border border-violet-500/20">
                  Fit: {rev.fitRating}
                </span>
              </div>
            </div>

            {/* Author Footer */}
            <div className="mt-6 pt-4 border-t border-white/10 dark:border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {rev.avatarUrl ? (
                  <img
                    src={rev.avatarUrl}
                    alt={rev.author}
                    className="w-8 h-8 rounded-full object-cover border border-white/20"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-neutral-700 flex items-center justify-center text-xs font-bold text-white border border-white/10">
                    {rev.author.charAt(0)}
                  </div>
                )}
                <div>
                  <div className="font-bold text-xs">{rev.author}</div>
                  <div className="text-[10px] text-neutral-400">{rev.location}</div>
                </div>
              </div>

              <span className="text-[10px] font-mono text-neutral-400">{rev.date}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Write a Review Modal */}
      {isWriteModalOpen && (
        <div
          id="write-review-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-fadeIn"
          onClick={() => setIsWriteModalOpen(false)}
        >
          <div
            id="write-review-card"
            className={`relative w-full max-w-lg rounded-2xl border p-6 sm:p-8 shadow-[0_20px_50px_rgba(0,0,0,0.6)] backdrop-blur-2xl ${
              isDark ? 'bg-[#0f0f15]/90 border-white/15 text-white' : 'bg-white/90 border-neutral-200 text-neutral-900'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 border-b border-white/10 dark:border-white/10">
              <h3 className="text-lg font-bold font-sans">Share Your MGW Experience</h3>
              <button
                onClick={() => setIsWriteModalOpen(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitReview} className="mt-5 space-y-4">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                  Rating (1-5 Stars)
                </label>
                <div className="flex items-center gap-2 mt-1.5">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setNewRating(num)}
                      className="p-1 text-amber-400"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          num <= newRating ? 'fill-current text-amber-400' : 'text-neutral-600'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={newAuthor}
                    onChange={(e) => setNewAuthor(e.target.value)}
                    placeholder="e.g. Julian Vance"
                    className={`w-full mt-1 px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-400 backdrop-blur-xl ${
                      isDark
                        ? 'bg-white/[0.04] border-white/15 text-white placeholder-neutral-500'
                        : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                    }`}
                  />
                </div>
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                    City, Country
                  </label>
                  <input
                    type="text"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    placeholder="e.g. Zurich, CH"
                    className={`w-full mt-1 px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-400 backdrop-blur-xl ${
                      isDark
                        ? 'bg-white/[0.04] border-white/15 text-white placeholder-neutral-500'
                        : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                  Headline
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Unbelievable comfort and featherweight titanium feel"
                  className={`w-full mt-1 px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-400 backdrop-blur-xl ${
                    isDark
                      ? 'bg-white/[0.04] border-white/15 text-white placeholder-neutral-500'
                      : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                  Review Details
                </label>
                <textarea
                  required
                  rows={3}
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="How did the fit feel? How was the hinge action and lens clarity?"
                  className={`w-full mt-1 px-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-400 backdrop-blur-xl ${
                    isDark
                      ? 'bg-white/[0.04] border-white/15 text-white placeholder-neutral-500'
                      : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                  }`}
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsWriteModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-6 py-2 rounded-xl text-xs font-bold transition-all border ${
                    isDark
                      ? 'bg-amber-400 text-black hover:bg-amber-300 border-amber-300 shadow-md'
                      : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                  }`}
                >
                  Publish Verified Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
