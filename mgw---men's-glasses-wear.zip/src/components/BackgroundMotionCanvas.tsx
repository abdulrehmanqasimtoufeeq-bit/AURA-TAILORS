import React, { useEffect, useRef, useState } from 'react';
import { Sparkles, Play, Pause, RefreshCw, Copy, Check } from 'lucide-react';
import { ThemeMode } from '../types';

interface BackgroundMotionCanvasProps {
  mode: 'abstract' | 'studio';
  theme: ThemeMode;
  onToggleMode: (mode: 'abstract' | 'studio') => void;
  onOpenPromptModal: () => void;
}

export const BackgroundMotionCanvas: React.FC<BackgroundMotionCanvasProps> = ({
  mode,
  theme,
  onToggleMode,
  onOpenPromptModal
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [copied, setCopied] = useState(false);
  const mousePosRef = useRef({ x: 0.5, y: 0.5, targetX: 0.5, targetY: 0.5 });
  const animationFrameRef = useRef<number | null>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mousePosRef.current.targetX = e.clientX / window.innerWidth;
      mousePosRef.current.targetY = e.clientY / window.innerHeight;
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Particle system & curves definition
    const curvesCount = 38;
    const particlesCount = 80;
    const particles = Array.from({ length: particlesCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 2 + 0.5,
      speedX: (Math.random() - 0.5) * 0.4,
      speedY: (Math.random() - 0.5) * 0.4,
      alpha: Math.random() * 0.7 + 0.2,
      depth: Math.random() * 2 + 0.5
    }));

    let time = 0;

    const render = () => {
      if (!isPlaying) {
        animationFrameRef.current = requestAnimationFrame(render);
        return;
      }

      time += 0.008;

      // Smooth mouse interpolation
      mousePosRef.current.x += (mousePosRef.current.targetX - mousePosRef.current.x) * 0.05;
      mousePosRef.current.y += (mousePosRef.current.targetY - mousePosRef.current.y) * 0.05;

      const mx = (mousePosRef.current.x - 0.5) * 60;
      const my = (mousePosRef.current.y - 0.5) * 60;

      ctx.clearRect(0, 0, width, height);

      const isDark = theme === 'dark';

      if (mode === 'abstract') {
        // Modern & Abstract Option: Glowing neon violet and metallic-grey curved lines swirling toward a dark center tunnel
        const centerX = width * 0.5 + mx;
        const centerY = height * 0.48 + my;

        // Background gradient radial
        const bgGrad = ctx.createRadialGradient(
          centerX,
          centerY,
          20,
          centerX,
          centerY,
          Math.max(width, height) * 0.85
        );

        if (isDark) {
          bgGrad.addColorStop(0, '#0c0714');
          bgGrad.addColorStop(0.35, '#120d1c');
          bgGrad.addColorStop(0.7, '#0f0f13');
          bgGrad.addColorStop(1, '#09090b');
        } else {
          bgGrad.addColorStop(0, '#f2e8f7');
          bgGrad.addColorStop(0.4, '#ede7df');
          bgGrad.addColorStop(0.8, '#f4f1ea');
          bgGrad.addColorStop(1, '#ebe6dc');
        }

        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, width, height);

        // Swirling metallic & violet curved lines
        for (let i = 0; i < curvesCount; i++) {
          const angleOffset = (i / curvesCount) * Math.PI * 2 + time * 0.6;
          const radiusMax = Math.min(width, height) * 0.7;
          const radiusMin = 30;

          const startX = centerX + Math.cos(angleOffset) * radiusMax;
          const startY = centerY + Math.sin(angleOffset) * radiusMax;

          const cp1Angle = angleOffset + Math.sin(time + i * 0.1) * 0.8 + 0.4;
          const cp1Dist = radiusMax * 0.65;
          const cp1X = centerX + Math.cos(cp1Angle) * cp1Dist;
          const cp1Y = centerY + Math.sin(cp1Angle) * cp1Dist;

          const cp2Angle = angleOffset - Math.cos(time * 0.8 + i * 0.2) * 0.9 + 1.2;
          const cp2Dist = radiusMax * 0.3;
          const cp2X = centerX + Math.cos(cp2Angle) * cp2Dist;
          const cp2Y = centerY + Math.sin(cp2Angle) * cp2Dist;

          const endX = centerX + Math.cos(angleOffset + 2.5) * radiusMin;
          const endY = centerY + Math.sin(angleOffset + 2.5) * radiusMin;

          ctx.beginPath();
          ctx.moveTo(startX, startY);
          ctx.bezierCurveTo(cp1X, cp1Y, cp2X, cp2Y, endX, endY);

          // Alternating metallic gunmetal vs glowing neon violet
          const isViolet = i % 3 === 0;
          const isGold = i % 5 === 0;

          ctx.lineWidth = isViolet ? 1.6 : 1.0;

          if (isViolet) {
            ctx.strokeStyle = isDark
              ? `rgba(168, 85, 247, ${0.45 + Math.sin(time * 2 + i) * 0.2})`
              : `rgba(147, 51, 234, ${0.35 + Math.sin(time * 2 + i) * 0.15})`;
            ctx.shadowColor = isDark ? 'rgba(168, 85, 247, 0.8)' : 'rgba(168, 85, 247, 0.4)';
            ctx.shadowBlur = isDark ? 12 : 6;
          } else if (isGold && isDark) {
            ctx.strokeStyle = `rgba(212, 175, 55, ${0.3 + Math.cos(time + i) * 0.15})`;
            ctx.shadowColor = 'rgba(212, 175, 55, 0.5)';
            ctx.shadowBlur = 8;
          } else {
            ctx.strokeStyle = isDark
              ? `rgba(160, 165, 180, ${0.25 + Math.sin(time + i) * 0.1})`
              : `rgba(90, 95, 110, ${0.2 + Math.sin(time + i) * 0.1})`;
            ctx.shadowColor = 'transparent';
            ctx.shadowBlur = 0;
          }

          ctx.stroke();
        }

        // Center tunnel vortex glow
        ctx.shadowBlur = 0;
        const tunnelGlow = ctx.createRadialGradient(
          centerX,
          centerY,
          0,
          centerX,
          centerY,
          180
        );
        tunnelGlow.addColorStop(
          0,
          isDark ? 'rgba(147, 51, 234, 0.35)' : 'rgba(168, 85, 247, 0.2)'
        );
        tunnelGlow.addColorStop(
          0.5,
          isDark ? 'rgba(99, 102, 241, 0.15)' : 'rgba(129, 140, 248, 0.1)'
        );
        tunnelGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = tunnelGlow;
        ctx.beginPath();
        ctx.arc(centerX, centerY, 180, 0, Math.PI * 2);
        ctx.fill();

      } else {
        // Option 2: Luxury Eyewear Showcase (Product Focused studio space)
        const centerX = width * 0.5 + mx * 0.6;
        const centerY = height * 0.45 + my * 0.6;

        // Luxury warm beige / dark slate studio gradient
        const studioGrad = ctx.createRadialGradient(
          centerX,
          centerY * 0.8,
          50,
          centerX,
          centerY,
          Math.max(width, height) * 0.8
        );

        if (isDark) {
          studioGrad.addColorStop(0, '#1c1b1f');
          studioGrad.addColorStop(0.4, '#151418');
          studioGrad.addColorStop(0.8, '#0d0d10');
          studioGrad.addColorStop(1, '#08080a');
        } else {
          studioGrad.addColorStop(0, '#faf7f2');
          studioGrad.addColorStop(0.4, '#f4eee4');
          studioGrad.addColorStop(0.8, '#ece4d6');
          studioGrad.addColorStop(1, '#e3dacb');
        }

        ctx.fillStyle = studioGrad;
        ctx.fillRect(0, 0, width, height);

        // Soft studio spotlight caustic sweeps
        const spotlightX = centerX + Math.sin(time * 0.8) * 120;
        const spotlightY = centerY * 0.6 + Math.cos(time * 0.6) * 60;
        const spotGrad = ctx.createRadialGradient(
          spotlightX,
          spotlightY,
          10,
          spotlightX,
          spotlightY,
          350
        );
        spotGrad.addColorStop(
          0,
          isDark ? 'rgba(235, 215, 180, 0.16)' : 'rgba(255, 245, 230, 0.5)'
        );
        spotGrad.addColorStop(
          0.6,
          isDark ? 'rgba(180, 160, 130, 0.05)' : 'rgba(230, 215, 195, 0.2)'
        );
        spotGrad.addColorStop(1, 'rgba(0,0,0,0)');

        ctx.fillStyle = spotGrad;
        ctx.beginPath();
        ctx.arc(spotlightX, spotlightY, 350, 0, Math.PI * 2);
        ctx.fill();

        // Elegant floating 3D wireframe glasses & concentric luxury pedestal rings
        const floatY = centerY + Math.sin(time * 1.2) * 15;
        const floatAngle = Math.sin(time * 0.7) * 0.08;

        ctx.save();
        ctx.translate(centerX, floatY);
        ctx.rotate(floatAngle);

        // Concentric luxury orbit rings
        for (let r = 0; r < 4; r++) {
          const ringRad = 180 + r * 65 + Math.sin(time + r) * 10;
          ctx.beginPath();
          ctx.ellipse(0, 40, ringRad, ringRad * 0.35, Math.sin(time * 0.4 + r) * 0.1, 0, Math.PI * 2);
          ctx.strokeStyle = isDark
            ? `rgba(215, 199, 178, ${0.12 - r * 0.02})`
            : `rgba(160, 140, 110, ${0.18 - r * 0.03})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }

        // Floating wireframe eyewear silhouette
        const scale = 1.35 + Math.sin(time * 0.5) * 0.05;
        ctx.scale(scale, scale);

        // Left Lens Rim
        ctx.beginPath();
        ctx.roundRect(-100, -30, 80, 52, 16);
        ctx.strokeStyle = isDark ? 'rgba(230, 215, 195, 0.5)' : 'rgba(80, 70, 60, 0.45)';
        ctx.lineWidth = 2.2;
        ctx.stroke();

        // Right Lens Rim
        ctx.beginPath();
        ctx.roundRect(20, -30, 80, 52, 16);
        ctx.stroke();

        // Double Bridge
        ctx.beginPath();
        ctx.moveTo(-20, -18);
        ctx.lineTo(20, -18);
        ctx.moveTo(-20, -6);
        ctx.lineTo(20, -6);
        ctx.strokeStyle = isDark ? 'rgba(212, 175, 55, 0.65)' : 'rgba(180, 140, 60, 0.6)';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Left Temple
        ctx.beginPath();
        ctx.moveTo(-100, -16);
        ctx.lineTo(-145, -35);
        ctx.lineTo(-170, -25);
        ctx.stroke();

        // Right Temple
        ctx.beginPath();
        ctx.moveTo(100, -16);
        ctx.lineTo(145, -35);
        ctx.lineTo(170, -25);
        ctx.stroke();

        // Lens Reflection / Shimmer
        const shimmerX = Math.sin(time * 1.5) * 60;
        ctx.beginPath();
        ctx.moveTo(-90 + shimmerX, -28);
        ctx.lineTo(-70 + shimmerX, 18);
        ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.25)' : 'rgba(255, 255, 255, 0.5)';
        ctx.lineWidth = 3;
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(30 + shimmerX, -28);
        ctx.lineTo(50 + shimmerX, 18);
        ctx.stroke();

        ctx.restore();
      }

      // Ambient Floating Dust / Light Specks
      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = isDark
          ? `rgba(220, 210, 240, ${p.alpha * 0.4})`
          : `rgba(120, 110, 95, ${p.alpha * 0.25})`;
        ctx.fill();
      });

      animationFrameRef.current = requestAnimationFrame(render);
    };

    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [mode, theme, isPlaying]);

  const copyPromptText = () => {
    const promptText =
      mode === 'abstract'
        ? 'A seamless 4K looping background video of glowing neon violet and metallic metallic-grey curved lines swirling smoothly toward a dark center tunnel. Ultra-high definition, dark mode aesthetic, elegant motion graphics, minimalist luxury atmosphere, smooth 60fps.'
        : 'A seamless 4K looping background video showing high-end men’s eyewear floating slowly in a luxury studio space. Soft warm beige and dark slate background, subtle warm studio lighting, slow cinematic zoom-in, photorealistic 8K render, clean luxury aesthetic.';

    navigator.clipboard.writeText(promptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="hero-motion-canvas-wrapper" className="absolute inset-0 pointer-events-none overflow-hidden z-0">
      <canvas
        ref={canvasRef}
        id="bg-motion-canvas"
        className="w-full h-full block"
      />

      {/* Floating Canvas Controls for Video Blueprint Modes */}
      <div className="absolute bottom-6 right-6 pointer-events-auto z-20 flex items-center gap-2 bg-black/50 dark:bg-black/60 backdrop-blur-2xl px-4 py-2 rounded-full border border-white/15 shadow-[0_10px_30px_rgba(0,0,0,0.5)] text-xs">
        <span className="text-neutral-400 font-mono hidden sm:inline text-[11px] uppercase tracking-wider">
          AI Motion:
        </span>
        <button
          id="btn-mode-abstract"
          onClick={() => onToggleMode('abstract')}
          className={`px-3.5 py-1 rounded-full font-semibold transition-all ${
            mode === 'abstract'
              ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
              : 'text-neutral-300 hover:text-white hover:bg-white/10'
          }`}
          title="Option 1: Modern & Abstract Neon Violet Swirl"
        >
          Neon Abstract
        </button>
        <button
          id="btn-mode-studio"
          onClick={() => onToggleMode('studio')}
          className={`px-3.5 py-1 rounded-full font-semibold transition-all ${
            mode === 'studio'
              ? 'bg-amber-500 text-black shadow-md shadow-amber-500/30'
              : 'text-neutral-300 hover:text-white hover:bg-white/10'
          }`}
          title="Option 2: Luxury Eyewear Studio Float"
        >
          Luxury Studio
        </button>

        <div className="h-4 w-px bg-white/15 mx-1" />

        <button
          id="btn-toggle-motion-play"
          onClick={() => setIsPlaying(!isPlaying)}
          className="p-1 text-neutral-300 hover:text-white transition-colors"
          title={isPlaying ? 'Pause Motion' : 'Resume Motion'}
          aria-label={isPlaying ? 'Pause Motion' : 'Resume Motion'}
        >
          {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
        </button>

        <button
          id="btn-view-prompts-modal"
          onClick={onOpenPromptModal}
          className="flex items-center gap-1.5 text-neutral-200 hover:text-white pl-1.5 transition-colors font-semibold"
          title="View & Copy AI Video Generator Prompts"
        >
          <Sparkles className="w-3.5 h-3.5 text-violet-400" />
          <span className="hidden md:inline">Prompts</span>
        </button>
      </div>
    </div>
  );
};
