import React, { useState } from 'react';
import { CartItem, ThemeMode } from '../types';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowRight,
  ShieldCheck,
  Tag,
  Check,
  CreditCard,
  Truck
} from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  theme: ThemeMode;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  theme
}) => {
  const isDark = theme === 'dark';

  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoError, setPromoError] = useState('');
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);

  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const discountAmount = (subtotal * discountPercent) / 100;
  const freeShippingThreshold = 250;
  const shipping = subtotal >= freeShippingThreshold || subtotal === 0 ? 0 : 25;
  const grandTotal = Math.max(0, subtotal - discountAmount + shipping);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const code = promoCode.trim().toUpperCase();
    if (code === 'MGW10' || code === 'PRECISION') {
      setDiscountPercent(15);
      setPromoError('');
    } else if (code === 'VIP') {
      setDiscountPercent(20);
      setPromoError('');
    } else {
      setPromoError('Invalid promotional code. Try MGW10 or PRECISION.');
    }
  };

  const handleSimulateCheckout = () => {
    setIsCheckingOut(true);
    setTimeout(() => {
      setIsCheckingOut(false);
      setOrderComplete(true);
      onClearCart();
    }, 1800);
  };

  if (!isOpen) return null;

  return (
    <div
      id="cart-drawer-backdrop"
      className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-xl animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="cart-drawer-panel"
        className={`relative w-full max-w-md h-full flex flex-col justify-between p-6 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.8)] backdrop-blur-2xl transition-all ${
          isDark
            ? 'bg-[#0f0f15]/95 border-l border-white/15 text-white'
            : 'bg-white/95 border-l border-neutral-200 text-neutral-900'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 dark:border-white/10">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-amber-400" />
            <h3 className="font-extrabold text-lg font-sans">Shopping Bag</h3>
            <span className="text-xs font-mono text-neutral-400">({cartItems.length} items)</span>
          </div>

          <button
            id="btn-close-cart"
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-white/10 border border-transparent hover:border-white/10 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Order Completed Screen */}
        {orderComplete ? (
          <div className="my-auto text-center py-8">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto mb-4 backdrop-blur-xl">
              <Check className="w-8 h-8" />
            </div>
            <h4 className="text-2xl font-bold font-sans">Order Confirmed</h4>
            <p className="text-xs text-neutral-400 mt-2 max-w-xs mx-auto leading-relaxed">
              Your bespoke MGW eyewear order <strong>#MGW-89420</strong> is now queued for micro-lathe fabrication and lens coating in our precision optics studio.
            </p>
            <div className="mt-6 p-4 rounded-xl bg-white/[0.04] border border-white/10 text-left text-xs font-mono space-y-1 backdrop-blur-xl">
              <div className="text-amber-400 font-bold">DISPATCH NOTICE:</div>
              <div className="text-neutral-300">Expedited DHL Express Air (2-3 Business Days)</div>
              <div className="text-neutral-400">Includes Aluminum Hard Vault Case & Lifetime Card</div>
            </div>
            <button
              onClick={() => {
                setOrderComplete(false);
                onClose();
              }}
              className={`mt-6 w-full py-3 rounded-xl text-xs font-bold uppercase tracking-wider border ${
                isDark ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40 shadow-sm' : 'bg-neutral-950 text-white border-black'
              }`}
            >
              Continue Exploring Collection
            </button>
          </div>
        ) : (
          <>
            {/* Free Shipping Meter */}
            <div className="mt-4 p-3 rounded-xl bg-violet-500/10 border border-violet-500/20 text-xs backdrop-blur-xl">
              <div className="flex items-center justify-between font-medium">
                <span className="flex items-center gap-1.5 text-violet-300">
                  <Truck className="w-3.5 h-3.5" />
                  {subtotal >= freeShippingThreshold
                    ? '🎉 You unlocked Free Express Worldwide Delivery!'
                    : `Add $${(freeShippingThreshold - subtotal).toFixed(0)} more for Free Express Shipping`}
                </span>
              </div>
              <div className="w-full h-1.5 bg-white/10 rounded-full mt-2 overflow-hidden">
                <div
                  className="h-full bg-violet-500 rounded-full transition-all duration-300"
                  style={{
                    width: `${Math.min(100, (subtotal / freeShippingThreshold) * 100)}%`
                  }}
                />
              </div>
            </div>

            {/* Cart Items List */}
            <div className="my-4 flex-1 overflow-y-auto pr-1 space-y-3">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-neutral-500 py-12">
                  <ShoppingBag className="w-12 h-12 stroke-[1.5] mb-3 opacity-40" />
                  <p className="font-medium text-sm">Your shopping bag is empty.</p>
                  <p className="text-xs text-neutral-400 mt-1 max-w-[200px]">
                    Explore the collection to configure your bespoke frames.
                  </p>
                </div>
              ) : (
                cartItems.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3.5 rounded-xl border flex gap-3 transition-all backdrop-blur-xl ${
                      isDark ? 'bg-white/[0.03] border-white/10' : 'bg-white/80 border-neutral-200'
                    }`}
                  >
                    <img
                      src={item.product.imageUrl}
                      alt={item.product.name}
                      className="w-16 h-14 object-contain rounded-lg bg-black/20 p-1 border border-white/10"
                    />

                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-xs">{item.product.name}</h4>
                          <span className="font-bold text-xs font-sans">
                            ${item.price * item.quantity}
                          </span>
                        </div>

                        <div className="text-[10px] text-neutral-400 mt-0.5 space-y-0.5">
                          <div>
                            Finish: <span className="text-neutral-300">{item.color.name}</span>
                          </div>
                          <div>
                            Lens: <span className="text-amber-400">{item.lensTint}</span>
                          </div>
                          {item.engravingText && (
                            <div>
                              Monogram: <span className="font-mono text-violet-400">{item.engravingText}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Quantity & Delete */}
                      <div className="mt-2 flex items-center justify-between pt-1 border-t border-white/10">
                        <div className="flex items-center gap-2 border border-white/15 bg-white/[0.03] rounded-lg px-2 py-0.5 text-xs">
                          <button
                            onClick={() => onUpdateQuantity(item.id, -1)}
                            className="text-neutral-400 hover:text-white"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="font-mono font-bold text-xs">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(item.id, 1)}
                            className="text-neutral-400 hover:text-white"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-neutral-500 hover:text-rose-400 p-1 transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Promo Code & Order Summary */}
            {cartItems.length > 0 && (
              <div className="pt-3 border-t border-white/10 dark:border-white/10 space-y-3">
                {/* Promo Code input */}
                <form onSubmit={handleApplyPromo} className="flex gap-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="PROMO: MGW10"
                    className={`flex-1 px-3 py-1.5 rounded-xl text-xs font-mono uppercase border focus:outline-none focus:ring-1 focus:ring-amber-400 backdrop-blur-xl ${
                      isDark
                        ? 'bg-white/[0.04] border-white/15 text-white placeholder-neutral-500'
                        : 'bg-neutral-50 border-neutral-300 text-neutral-900'
                    }`}
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/20 border border-white/15 text-white transition-all"
                  >
                    Apply
                  </button>
                </form>
                {discountPercent > 0 && (
                  <p className="text-[10px] text-emerald-400 font-mono">
                    ✓ {discountPercent}% Exclusive Gentleman VIP Discount applied!
                  </p>
                )}
                {promoError && (
                  <p className="text-[10px] text-rose-400 font-mono">{promoError}</p>
                )}

                {/* Subtotals */}
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-neutral-400">
                    <span>Subtotal</span>
                    <span className="font-mono text-neutral-200">${subtotal}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-emerald-400">
                      <span>VIP Discount ({discountPercent}%)</span>
                      <span className="font-mono">-${discountAmount.toFixed(0)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-neutral-400">
                    <span>Express Worldwide Delivery</span>
                    <span className="font-mono">
                      {shipping === 0 ? 'FREE' : `$${shipping}`}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-extrabold pt-2 border-t border-white/10">
                    <span>Total Amount</span>
                    <span className="text-base text-amber-400 font-sans">
                      ${grandTotal.toFixed(0)}
                    </span>
                  </div>
                </div>

                {/* Checkout CTA */}
                <button
                  id="btn-checkout-submit"
                  onClick={handleSimulateCheckout}
                  disabled={isCheckingOut}
                  className={`w-full py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-xl border ${
                    isDark
                      ? 'bg-white text-neutral-950 hover:bg-neutral-100 border-white/40'
                      : 'bg-neutral-950 text-white hover:bg-neutral-800 border-black'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>
                    {isCheckingOut
                      ? 'Securing Transaction...'
                      : `Proceed to Express Checkout ($${grandTotal.toFixed(0)})`}
                  </span>
                </button>

                <div className="flex items-center justify-center gap-3 text-[10px] text-neutral-400">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" /> 256-Bit SSL Encrypted
                  </span>
                  <span>•</span>
                  <span>Apple Pay / Visa / Amex</span>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
